package com.forecaster.api.dto;

import jakarta.validation.constraints.*;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;

public final class ForecastDtos {

    private ForecastDtos() {}

    // --- Sprint Data ---

    public record AddSprintRequest(
            @NotBlank String sprintName,
            @NotNull LocalDate startDate,
            @NotNull LocalDate endDate,
            @Min(0) int committedPoints,
            @Min(0) int completedPoints,
            @Min(0) int carryOverPoints
    ) {}

    public record SprintResponse(
            String sprintName,
            LocalDate startDate,
            LocalDate endDate,
            int committedPoints,
            int completedPoints,
            int carryOverPoints,
            int velocity,
            double commitmentAccuracy
    ) {}

    // --- Epic ---

    public record CreateEpicRequest(
            @NotBlank String id,
            @NotBlank String name,
            @Min(1) int totalPoints,
            @Min(0) int completedPoints
    ) {}

    public record EpicResponse(
            String id,
            String name,
            int totalPoints,
            int completedPoints,
            int remainingPoints,
            double progressPercent,
            String status
    ) {}

    // --- Forecast ---

    public record ForecastRequest(
            @NotBlank String epicId,
            String strategy,
            Integer iterations,
            Double confidenceLevel,
            Integer sprintLengthDays,
            boolean removeOutliers
    ) {}

    public record ForecastResponse(
            String strategyName,
            int estimatedSprints,
            int bestCase,
            int worstCase,
            LocalDate estimatedDate,
            LocalDate bestCaseDate,
            LocalDate worstCaseDate,
            double confidenceLevel,
            double averageVelocity,
            String summary,
            Map<String, Object> metadata
    ) {}

    public record ComparisonResponse(
            String epicId,
            String epicName,
            int remainingPoints,
            List<ForecastResponse> forecasts,
            double consensusSprints,
            ForecastResponse mostOptimistic,
            ForecastResponse mostConservative,
            long totalDurationMs
    ) {}

    // --- Velocity Stats ---

    public record VelocityStatsResponse(
            double mean,
            double standardDeviation,
            double min,
            double max,
            double p50,
            double p85,
            int sprintCount
    ) {}
}
