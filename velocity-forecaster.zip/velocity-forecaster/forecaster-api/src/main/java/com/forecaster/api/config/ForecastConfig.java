package com.forecaster.api.config;

import com.forecaster.core.engine.ForecastEngine;
import com.forecaster.core.pipeline.DefaultForecastPipeline;
import com.forecaster.core.pipeline.OutlierRemovingPipeline;
import com.forecaster.core.strategy.*;
import com.forecaster.api.store.InMemoryStore;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ForecastConfig {

    @Bean
    public ForecastEngine forecastEngine() {
        return ForecastEngine.builder()
                .addStrategy(new AverageVelocityStrategy())
                .addStrategy(new WeightedVelocityStrategy())
                .addStrategy(new MonteCarloStrategy())
                .pipeline(new DefaultForecastPipeline())
                .build();
    }

    @Bean
    public ForecastEngine outlierAwareEngine() {
        return ForecastEngine.builder()
                .addStrategy(new AverageVelocityStrategy())
                .addStrategy(new WeightedVelocityStrategy())
                .addStrategy(new MonteCarloStrategy())
                .pipeline(new OutlierRemovingPipeline())
                .build();
    }

    /**
     * Seed sample data on startup for demo purposes.
     */
    @Bean
    public CommandLineRunner seedData(InMemoryStore store) {
        return args -> store.seedSampleData();
    }
}
