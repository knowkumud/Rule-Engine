package com.forecaster.api.store;

import com.forecaster.core.model.Epic;
import com.forecaster.core.model.SprintSnapshot;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Thread-safe in-memory store.
 *
 * <p>Uses {@link ConcurrentHashMap} for epics (keyed by ID) and
 * {@link CopyOnWriteArrayList} for sprint history (append-heavy, read-heavy).
 * No database needed for this project scope.</p>
 */
@Component
public class InMemoryStore {

    private final ConcurrentHashMap<String, Epic> epics = new ConcurrentHashMap<>();
    private final CopyOnWriteArrayList<SprintSnapshot> sprintHistory = new CopyOnWriteArrayList<>();

    // --- Sprints ---

    public void addSprint(SprintSnapshot sprint) {
        sprintHistory.add(sprint);
    }

    public List<SprintSnapshot> getAllSprints() {
        return Collections.unmodifiableList(sprintHistory);
    }

    public void clearSprints() {
        sprintHistory.clear();
    }

    // --- Epics ---

    public void saveEpic(Epic epic) {
        epics.put(epic.getId(), epic);
    }

    public Optional<Epic> getEpic(String id) {
        return Optional.ofNullable(epics.get(id));
    }

    public List<Epic> getAllEpics() {
        return List.copyOf(epics.values());
    }

    public void removeEpic(String id) {
        epics.remove(id);
    }

    /**
     * Seed sample data for demo/testing.
     */
    public void seedSampleData() {
        clearSprints();
        epics.clear();

        addSprint(new SprintSnapshot("Sprint 1", java.time.LocalDate.of(2025, 1, 6), java.time.LocalDate.of(2025, 1, 17), 20, 18, 2));
        addSprint(new SprintSnapshot("Sprint 2", java.time.LocalDate.of(2025, 1, 20), java.time.LocalDate.of(2025, 1, 31), 20, 22, 0));
        addSprint(new SprintSnapshot("Sprint 3", java.time.LocalDate.of(2025, 2, 3), java.time.LocalDate.of(2025, 2, 14), 22, 20, 2));
        addSprint(new SprintSnapshot("Sprint 4", java.time.LocalDate.of(2025, 2, 17), java.time.LocalDate.of(2025, 2, 28), 20, 19, 1));
        addSprint(new SprintSnapshot("Sprint 5", java.time.LocalDate.of(2025, 3, 3), java.time.LocalDate.of(2025, 3, 14), 21, 24, 0));
        addSprint(new SprintSnapshot("Sprint 6", java.time.LocalDate.of(2025, 3, 17), java.time.LocalDate.of(2025, 3, 28), 22, 21, 1));

        saveEpic(Epic.builder().id("EPIC-001").name("Customer Portal Redesign")
                .totalPoints(120).completedPoints(40).status(com.forecaster.core.model.EpicStatus.IN_PROGRESS).build());
        saveEpic(Epic.builder().id("EPIC-002").name("API Gateway Migration")
                .totalPoints(80).completedPoints(15).status(com.forecaster.core.model.EpicStatus.IN_PROGRESS).build());
    }
}
