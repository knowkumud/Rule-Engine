package com.forecaster.api.controller;

import com.forecaster.api.dto.ForecastDtos.*;
import com.forecaster.api.store.InMemoryStore;
import com.forecaster.core.data.DataSeries;
import com.forecaster.core.engine.ForecastEngine;
import com.forecaster.core.engine.ForecastEngine.ForecastComparison;
import com.forecaster.core.model.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1")
@Tag(name = "Velocity Forecaster", description = "Sprint velocity tracking and epic completion forecasting")
public class ForecastController {

    private final InMemoryStore store;
    private final ForecastEngine defaultEngine;
    private final ForecastEngine outlierEngine;

    public ForecastController(InMemoryStore store,
                               @Qualifier("forecastEngine") ForecastEngine defaultEngine,
                               @Qualifier("outlierAwareEngine") ForecastEngine outlierEngine) {
        this.store = store;
        this.defaultEngine = defaultEngine;
        this.outlierEngine = outlierEngine;
    }

    // ========== SPRINTS ==========

    @PostMapping("/sprints")
    @Operation(summary = "Add a completed sprint")
    public ResponseEntity<SprintResponse> addSprint(@Valid @RequestBody AddSprintRequest req) {
        SprintSnapshot sprint = new SprintSnapshot(
                req.sprintName(), req.startDate(), req.endDate(),
                req.committedPoints(), req.completedPoints(), req.carryOverPoints());
        store.addSprint(sprint);
        return ResponseEntity.status(HttpStatus.CREATED).body(toSprintResponse(sprint));
    }

    @GetMapping("/sprints")
    @Operation(summary = "List all sprints")
    public List<SprintResponse> listSprints() {
        return store.getAllSprints().stream().map(this::toSprintResponse).toList();
    }

    // ========== EPICS ==========

    @PostMapping("/epics")
    @Operation(summary = "Create an epic to forecast")
    public ResponseEntity<EpicResponse> createEpic(@Valid @RequestBody CreateEpicRequest req) {
        Epic epic = Epic.builder()
                .id(req.id()).name(req.name())
                .totalPoints(req.totalPoints()).completedPoints(req.completedPoints())
                .status(EpicStatus.IN_PROGRESS)
                .build();
        store.saveEpic(epic);
        return ResponseEntity.status(HttpStatus.CREATED).body(toEpicResponse(epic));
    }

    @GetMapping("/epics")
    @Operation(summary = "List all epics")
    public List<EpicResponse> listEpics() {
        return store.getAllEpics().stream().map(this::toEpicResponse).toList();
    }

    @GetMapping("/epics/{epicId}")
    @Operation(summary = "Get epic details")
    public ResponseEntity<EpicResponse> getEpic(@PathVariable String epicId) {
        return store.getEpic(epicId)
                .map(e -> ResponseEntity.ok(toEpicResponse(e)))
                .orElse(ResponseEntity.notFound().build());
    }

    // ========== FORECASTING ==========

    @PostMapping("/forecast")
    @Operation(summary = "Forecast epic completion — single strategy or compare all")
    public ResponseEntity<?> forecast(@Valid @RequestBody ForecastRequest req) {
        Epic epic = store.getEpic(req.epicId())
                .orElseThrow(() -> new IllegalArgumentException("Epic not found: " + req.epicId()));

        List<SprintSnapshot> history = store.getAllSprints();
        if (history.isEmpty()) {
            return ResponseEntity.badRequest().body("No sprint data available");
        }

        SimulationConfig config = SimulationConfig.builder()
                .iterations(req.iterations() != null ? req.iterations() : 10_000)
                .confidenceLevel(req.confidenceLevel() != null ? req.confidenceLevel() : 0.85)
                .sprintLengthDays(req.sprintLengthDays() != null ? req.sprintLengthDays() : 14)
                .build();

        ForecastEngine engine = req.removeOutliers() ? outlierEngine : defaultEngine;

        // Single strategy or compare all?
        if (req.strategy() != null && !req.strategy().isBlank()) {
            return engine.forecastWith(req.strategy(), epic, history, config)
                    .map(r -> ResponseEntity.ok(toForecastResponse(r)))
                    .orElse(ResponseEntity.badRequest().build());
        }

        // Compare all strategies
        ForecastComparison comparison = engine.forecastAll(epic, history, config);
        return ResponseEntity.ok(toComparisonResponse(epic, comparison));
    }

    @GetMapping("/forecast/strategies")
    @Operation(summary = "List available forecast strategies")
    public List<String> listStrategies() {
        return defaultEngine.getAvailableStrategies();
    }

    // ========== VELOCITY STATS ==========

    @GetMapping("/velocity/stats")
    @Operation(summary = "Velocity statistics across all sprints")
    public ResponseEntity<VelocityStatsResponse> velocityStats() {
        List<SprintSnapshot> history = store.getAllSprints();
        if (history.isEmpty()) {
            return ResponseEntity.badRequest().build();
        }

        DataSeries<Integer> velocities = DataSeries.of(
                history.stream().map(SprintSnapshot::velocity).toList());

        return ResponseEntity.ok(new VelocityStatsResponse(
                velocities.mean(),
                velocities.standardDeviation(),
                velocities.min(),
                velocities.max(),
                velocities.percentile(0.50),
                velocities.percentile(0.85),
                velocities.size()
        ));
    }

    // ========== MAPPERS ==========

    private SprintResponse toSprintResponse(SprintSnapshot s) {
        return new SprintResponse(s.sprintName(), s.startDate(), s.endDate(),
                s.committedPoints(), s.completedPoints(), s.carryOverPoints(),
                s.velocity(), s.commitmentAccuracy());
    }

    private EpicResponse toEpicResponse(Epic e) {
        return new EpicResponse(e.getId(), e.getName(), e.getTotalPoints(),
                e.getCompletedPoints(), e.getRemainingPoints(),
                e.getProgressPercent(), e.getStatus().name());
    }

    private ForecastResponse toForecastResponse(ForecastResult r) {
        return new ForecastResponse(r.strategyName(), r.estimatedSprints(),
                r.bestCase(), r.worstCase(), r.estimatedDate(),
                r.bestCaseDate(), r.worstCaseDate(), r.confidenceLevel(),
                r.averageVelocity(), r.toSummary(), r.metadata());
    }

    private ComparisonResponse toComparisonResponse(Epic epic, ForecastComparison c) {
        return new ComparisonResponse(
                epic.getId(), epic.getName(), epic.getRemainingPoints(),
                c.results().stream().map(this::toForecastResponse).toList(),
                c.consensusSprints(),
                c.mostOptimistic().map(this::toForecastResponse).orElse(null),
                c.mostConservative().map(this::toForecastResponse).orElse(null),
                c.totalDurationMs()
        );
    }
}
