package com.forecaster.core.model;

import java.time.LocalDate;
import java.util.Objects;

/**
 * Immutable snapshot of a completed sprint.
 * Record gives us equals/hashCode/toString for free.
 *
 * <p>This is the raw data that forecast models consume.
 * Each snapshot captures what was committed vs delivered.</p>
 *
 * @param sprintName    sprint identifier (e.g., "Sprint 24")
 * @param startDate     sprint start date
 * @param endDate       sprint end date
 * @param committedPoints  story points committed at sprint start
 * @param completedPoints  story points actually delivered
 * @param carryOverPoints  points carried to next sprint
 */
public record SprintSnapshot(
        String sprintName,
        LocalDate startDate,
        LocalDate endDate,
        int committedPoints,
        int completedPoints,
        int carryOverPoints
) {

    /**
     * Compact constructor — validates invariants.
     */
    public SprintSnapshot {
        Objects.requireNonNull(sprintName, "Sprint name required");
        Objects.requireNonNull(startDate, "Start date required");
        Objects.requireNonNull(endDate, "End date required");
        if (endDate.isBefore(startDate)) {
            throw new IllegalArgumentException("End date cannot be before start date");
        }
        if (completedPoints < 0 || committedPoints < 0) {
            throw new IllegalArgumentException("Points cannot be negative");
        }
    }

    /**
     * Velocity = completed points per sprint.
     * This is the key metric all forecast models use.
     */
    public int velocity() {
        return completedPoints;
    }

    /**
     * Commitment accuracy — how well did the team estimate?
     * 1.0 = perfect. > 1.0 = over-delivered. < 1.0 = under-delivered.
     */
    public double commitmentAccuracy() {
        return committedPoints == 0 ? 0.0 : (double) completedPoints / committedPoints;
    }

    /**
     * Sprint duration in days. Useful for normalizing velocity
     * when sprint lengths vary.
     */
    public long durationDays() {
        return java.time.temporal.ChronoUnit.DAYS.between(startDate, endDate);
    }
}
