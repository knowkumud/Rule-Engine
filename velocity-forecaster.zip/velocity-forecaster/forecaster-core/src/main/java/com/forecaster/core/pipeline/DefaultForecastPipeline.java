package com.forecaster.core.pipeline;

/**
 * Default pipeline — uses all base implementations.
 * Good for most teams. No outlier removal, no special normalization.
 */
public final class DefaultForecastPipeline extends ForecastPipeline {
    // Inherits all default behavior from ForecastPipeline.
    // Exists as a concrete class for instantiation.
}
