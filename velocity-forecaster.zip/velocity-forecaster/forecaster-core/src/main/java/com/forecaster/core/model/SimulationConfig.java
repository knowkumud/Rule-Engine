package com.forecaster.core.model;

/**
 * Configuration for forecast simulations.
 * Builder pattern with strict validation — invalid configs fail fast.
 *
 * <p>Example:</p>
 * <pre>
 * SimulationConfig config = SimulationConfig.builder()
 *     .iterations(10_000)
 *     .confidenceLevel(0.85)
 *     .sprintLengthDays(14)
 *     .useWeightedRecent(true)
 *     .recentSprintWeight(3)
 *     .build();
 * </pre>
 */
public final class SimulationConfig {

    private final int iterations;
    private final double confidenceLevel;
    private final int sprintLengthDays;
    private final boolean useWeightedRecent;
    private final int recentSprintWeight;

    private SimulationConfig(Builder builder) {
        this.iterations = builder.iterations;
        this.confidenceLevel = builder.confidenceLevel;
        this.sprintLengthDays = builder.sprintLengthDays;
        this.useWeightedRecent = builder.useWeightedRecent;
        this.recentSprintWeight = builder.recentSprintWeight;
    }

    public int getIterations() { return iterations; }
    public double getConfidenceLevel() { return confidenceLevel; }
    public int getSprintLengthDays() { return sprintLengthDays; }
    public boolean isUseWeightedRecent() { return useWeightedRecent; }
    public int getRecentSprintWeight() { return recentSprintWeight; }

    /**
     * Sensible defaults for quick usage.
     */
    public static SimulationConfig defaults() {
        return builder().build();
    }

    public static Builder builder() { return new Builder(); }

    public static final class Builder {
        private int iterations = 10_000;
        private double confidenceLevel = 0.85;
        private int sprintLengthDays = 14;
        private boolean useWeightedRecent = false;
        private int recentSprintWeight = 3;

        private Builder() {}

        public Builder iterations(int n) { this.iterations = n; return this; }
        public Builder confidenceLevel(double level) { this.confidenceLevel = level; return this; }
        public Builder sprintLengthDays(int days) { this.sprintLengthDays = days; return this; }
        public Builder useWeightedRecent(boolean use) { this.useWeightedRecent = use; return this; }
        public Builder recentSprintWeight(int weight) { this.recentSprintWeight = weight; return this; }

        public SimulationConfig build() {
            if (iterations < 100 || iterations > 1_000_000) {
                throw new IllegalStateException("Iterations must be 100–1,000,000. Got: " + iterations);
            }
            if (confidenceLevel <= 0.0 || confidenceLevel >= 1.0) {
                throw new IllegalStateException("Confidence must be between 0 and 1 exclusive. Got: " + confidenceLevel);
            }
            if (sprintLengthDays < 1 || sprintLengthDays > 30) {
                throw new IllegalStateException("Sprint length must be 1–30 days. Got: " + sprintLengthDays);
            }
            if (recentSprintWeight < 1) {
                throw new IllegalStateException("Recent sprint weight must be >= 1. Got: " + recentSprintWeight);
            }
            return new SimulationConfig(this);
        }
    }
}
