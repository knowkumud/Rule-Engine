package com.forecaster.core.engine;

import com.forecaster.core.model.*;
import com.forecaster.core.pipeline.ForecastPipeline;
import com.forecaster.core.strategy.ForecastStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.concurrent.*;

/**
 * Forecast engine that runs multiple strategies in parallel.
 *
 * <p>Uses {@link CompletableFuture#supplyAsync} to kick off each strategy
 * on a separate thread, then {@code allOf()} to wait for all to complete.
 * This means 3 strategies run in ~1x time, not 3x.</p>
 *
 * <p>Thread-safe: no mutable state between calls. Multiple threads
 * can call {@code forecastAll()} concurrently.</p>
 */
public final class ForecastEngine {

    private static final Logger log = LoggerFactory.getLogger(ForecastEngine.class);

    private final List<ForecastStrategy> strategies;
    private final ForecastPipeline pipeline;
    private final ExecutorService executor;
    private final long timeoutMs;

    private ForecastEngine(Builder builder) {
        this.strategies = Collections.unmodifiableList(new ArrayList<>(builder.strategies));
        this.pipeline = builder.pipeline;
        this.executor = builder.executor;
        this.timeoutMs = builder.timeoutMs;
    }

    /**
     * Run ALL strategies in parallel and return a comparison.
     * Each strategy gets its own thread via CompletableFuture.
     */
    public ForecastComparison forecastAll(Epic epic, List<SprintSnapshot> history,
                                           SimulationConfig config) {
        log.info("Forecasting epic '{}' ({} remaining pts) with {} strategies",
                epic.getName(), epic.getRemainingPoints(), strategies.size());

        long start = System.nanoTime();

        // Launch each strategy on its own thread
        List<CompletableFuture<ForecastResult>> futures = strategies.stream()
                .map(strategy -> CompletableFuture.supplyAsync(
                        () -> runSafe(epic, history, strategy, config), executor))
                .toList();

        // Wait for all to complete with timeout
        try {
            CompletableFuture.allOf(futures.toArray(new CompletableFuture[0]))
                    .get(timeoutMs, TimeUnit.MILLISECONDS);
        } catch (TimeoutException e) {
            log.error("Forecast timed out after {}ms", timeoutMs);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        } catch (ExecutionException e) {
            log.error("Forecast execution error", e);
        }

        // Collect completed results
        List<ForecastResult> results = futures.stream()
                .filter(f -> f.isDone() && !f.isCompletedExceptionally())
                .map(f -> {
                    try { return f.get(); }
                    catch (Exception e) { return null; }
                })
                .filter(Objects::nonNull)
                .toList();

        long durationMs = (System.nanoTime() - start) / 1_000_000;

        return new ForecastComparison(epic, results, config, durationMs);
    }

    /**
     * Run a single strategy through the pipeline.
     * Catches exceptions so one failing strategy doesn't kill the others.
     */
    private ForecastResult runSafe(Epic epic, List<SprintSnapshot> history,
                                    ForecastStrategy strategy, SimulationConfig config) {
        try {
            return pipeline.forecast(epic, history, strategy, config);
        } catch (Exception e) {
            log.error("Strategy '{}' failed: {}", strategy.getName(), e.getMessage());
            throw new CompletionException(e);
        }
    }

    /**
     * Run a single named strategy.
     */
    public Optional<ForecastResult> forecastWith(String strategyName, Epic epic,
                                                   List<SprintSnapshot> history,
                                                   SimulationConfig config) {
        return strategies.stream()
                .filter(s -> s.getName().equalsIgnoreCase(strategyName))
                .findFirst()
                .map(s -> pipeline.forecast(epic, history, s, config));
    }

    public List<String> getAvailableStrategies() {
        return strategies.stream().map(ForecastStrategy::getName).toList();
    }

    // --- BUILDER ---

    public static Builder builder() { return new Builder(); }

    public static final class Builder {
        private final List<ForecastStrategy> strategies = new ArrayList<>();
        private ForecastPipeline pipeline;
        private ExecutorService executor;
        private long timeoutMs = 10_000;

        private Builder() {}

        public Builder addStrategy(ForecastStrategy strategy) {
            this.strategies.add(strategy);
            return this;
        }

        public Builder pipeline(ForecastPipeline pipeline) {
            this.pipeline = pipeline;
            return this;
        }

        public Builder executor(ExecutorService executor) {
            this.executor = executor;
            return this;
        }

        public Builder timeoutMs(long ms) {
            this.timeoutMs = ms;
            return this;
        }

        public ForecastEngine build() {
            if (strategies.isEmpty()) {
                throw new IllegalStateException("At least one strategy is required");
            }
            if (pipeline == null) {
                pipeline = new com.forecaster.core.pipeline.DefaultForecastPipeline();
            }
            if (executor == null) {
                executor = Executors.newFixedThreadPool(strategies.size(), r -> {
                    Thread t = new Thread(r, "forecast-worker");
                    t.setDaemon(true);
                    return t;
                });
            }
            return new ForecastEngine(this);
        }
    }

    // --- COMPARISON RESULT ---

    /**
     * Side-by-side comparison of all strategy results.
     * Immutable record with helper methods for the API layer.
     */
    public record ForecastComparison(
            Epic epic,
            List<ForecastResult> results,
            SimulationConfig config,
            long totalDurationMs
    ) {
        public ForecastComparison {
            results = Collections.unmodifiableList(results);
        }

        /**
         * The most conservative (pessimistic) forecast.
         */
        public Optional<ForecastResult> mostConservative() {
            return results.stream()
                    .max(Comparator.comparingInt(ForecastResult::worstCase));
        }

        /**
         * The most optimistic forecast.
         */
        public Optional<ForecastResult> mostOptimistic() {
            return results.stream()
                    .min(Comparator.comparingInt(ForecastResult::bestCase));
        }

        /**
         * Consensus estimate — average of all strategy medians.
         */
        public double consensusSprints() {
            return results.stream()
                    .mapToInt(ForecastResult::estimatedSprints)
                    .average()
                    .orElse(0);
        }
    }
}
