package com.forecaster.core.strategy;

import com.forecaster.core.data.DataSeries;
import com.forecaster.core.model.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * Simplest model: remaining points / average velocity = sprints left.
 *
 * <p>Uses the full sprint history equally. Good baseline, but doesn't
 * account for the team getting faster or slower over time.</p>
 */
public final class AverageVelocityStrategy implements ForecastStrategy {

    @Override
    public String getName() { return "AVERAGE_VELOCITY"; }

    @Override
    public ForecastResult forecast(Epic epic, List<SprintSnapshot> history, SimulationConfig config) {
        DataSeries<Integer> velocities = extractVelocities(history);

        double avgVelocity = velocities.mean();
        double stdDev = velocities.standardDeviation();
        int remaining = epic.getRemainingPoints();

        if (avgVelocity <= 0) {
            throw new IllegalArgumentException("Average velocity is zero — cannot forecast");
        }

        // Point estimate
        int estimatedSprints = (int) Math.ceil(remaining / avgVelocity);

        // Confidence band using standard deviation
        // Best case: velocity + 1 stddev (team is fast)
        // Worst case: velocity - 1 stddev (team is slow)
        double optimisticVelocity = Math.max(1, avgVelocity + stdDev);
        double pessimisticVelocity = Math.max(1, avgVelocity - stdDev);

        int bestCase = (int) Math.ceil(remaining / optimisticVelocity);
        int worstCase = (int) Math.ceil(remaining / pessimisticVelocity);

        LocalDate today = LocalDate.now();
        int sprintDays = config.getSprintLengthDays();

        return new ForecastResult(
                getName(),
                estimatedSprints,
                bestCase,
                worstCase,
                today.plusDays((long) estimatedSprints * sprintDays),
                today.plusDays((long) bestCase * sprintDays),
                today.plusDays((long) worstCase * sprintDays),
                config.getConfidenceLevel(),
                avgVelocity,
                Map.of(
                        "standardDeviation", stdDev,
                        "sprintsAnalyzed", history.size(),
                        "remainingPoints", remaining
                )
        );
    }

    private DataSeries<Integer> extractVelocities(List<SprintSnapshot> history) {
        List<Integer> velocities = history.stream()
                .map(SprintSnapshot::velocity)
                .toList();
        return DataSeries.of(velocities);
    }
}
