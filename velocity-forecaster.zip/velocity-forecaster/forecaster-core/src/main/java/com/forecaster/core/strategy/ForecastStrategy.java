package com.forecaster.core.strategy;

import com.forecaster.core.model.Epic;
import com.forecaster.core.model.ForecastResult;
import com.forecaster.core.model.SimulationConfig;
import com.forecaster.core.model.SprintSnapshot;

import java.util.List;

/**
 * STRATEGY PATTERN: Each implementation provides a different
 * forecasting algorithm. The engine runs all strategies in parallel
 * and lets the consumer compare results.
 *
 * <p>Implementations:</p>
 * <ul>
 *   <li>{@link AverageVelocityStrategy} — simple mean velocity</li>
 *   <li>{@link WeightedVelocityStrategy} — recent sprints weighted higher</li>
 *   <li>{@link MonteCarloStrategy} — probabilistic simulation</li>
 * </ul>
 */
public interface ForecastStrategy {

    /**
     * Unique name for this strategy. Used in results and API responses.
     */
    String getName();

    /**
     * Forecast when the epic will be completed based on sprint history.
     *
     * @param epic      the epic to forecast
     * @param history   completed sprint snapshots (oldest → newest)
     * @param config    simulation configuration
     * @return forecast result with confidence intervals
     */
    ForecastResult forecast(Epic epic, List<SprintSnapshot> history, SimulationConfig config);
}
