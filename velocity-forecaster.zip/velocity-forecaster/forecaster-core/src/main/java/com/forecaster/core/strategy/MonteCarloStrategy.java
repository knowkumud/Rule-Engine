package com.forecaster.core.strategy;

import com.forecaster.core.data.DataSeries;
import com.forecaster.core.model.*;

import java.time.LocalDate;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

/**
 * MONTE CARLO SIMULATION: Runs thousands of random scenarios
 * by sampling from historical velocity data.
 *
 * <p>Instead of "average says 5 sprints," this answers:
 * "In 85% of 10,000 simulations, it took 4–7 sprints."</p>
 *
 * <p>Uses {@link ThreadLocalRandom} — not {@code Math.random()} or
 * shared {@code Random}. ThreadLocalRandom is:</p>
 * <ul>
 *   <li>Thread-safe without synchronization (each thread has its own)</li>
 *   <li>3x faster than synchronized {@code Random} under contention</li>
 *   <li>The correct choice for concurrent simulations</li>
 * </ul>
 */
public final class MonteCarloStrategy implements ForecastStrategy {

    @Override
    public String getName() { return "MONTE_CARLO"; }

    @Override
    public ForecastResult forecast(Epic epic, List<SprintSnapshot> history, SimulationConfig config) {
        List<Integer> velocities = history.stream()
                .map(SprintSnapshot::velocity)
                .toList();

        int remaining = epic.getRemainingPoints();
        int iterations = config.getIterations();

        // Run N simulations — each picks random velocities from history
        int[] sprintCounts = runSimulations(remaining, velocities, iterations);

        // Sort for percentile extraction
        Arrays.sort(sprintCounts);
        DataSeries<Integer> results = DataSeries.of(
                Arrays.stream(sprintCounts).boxed().toList()
        );

        double confidence = config.getConfidenceLevel();
        double lowPercentile = (1.0 - confidence) / 2;         // e.g., 0.075 for 85%
        double highPercentile = 1.0 - lowPercentile;            // e.g., 0.925

        int bestCase = (int) results.percentile(lowPercentile);
        int worstCase = (int) results.percentile(highPercentile);
        int estimate = (int) results.percentile(0.50);          // median

        double avgVelocity = velocities.stream()
                .mapToInt(Integer::intValue).average().orElse(0);

        LocalDate today = LocalDate.now();
        int sprintDays = config.getSprintLengthDays();

        return new ForecastResult(
                getName(),
                estimate,
                bestCase,
                worstCase,
                today.plusDays((long) estimate * sprintDays),
                today.plusDays((long) bestCase * sprintDays),
                today.plusDays((long) worstCase * sprintDays),
                confidence,
                avgVelocity,
                Map.of(
                        "iterations", iterations,
                        "medianSprints", estimate,
                        "p10", (int) results.percentile(0.10),
                        "p50", (int) results.percentile(0.50),
                        "p90", (int) results.percentile(0.90),
                        "remainingPoints", remaining
                )
        );
    }

    /**
     * Core simulation loop. For each iteration:
     * 1. Start with remaining points
     * 2. Each "sprint," randomly sample a velocity from history
     * 3. Subtract from remaining. Count sprints until done.
     *
     * <p>ThreadLocalRandom.current() returns this thread's RNG —
     * no locking, no contention, no shared state.</p>
     */
    private int[] runSimulations(int remainingPoints, List<Integer> velocities, int iterations) {
        int[] results = new int[iterations];
        int velocityCount = velocities.size();

        for (int i = 0; i < iterations; i++) {
            int pointsLeft = remainingPoints;
            int sprints = 0;

            while (pointsLeft > 0) {
                // Random sample from historical velocities
                int randomIndex = ThreadLocalRandom.current().nextInt(velocityCount);
                int velocity = velocities.get(randomIndex);

                // Add some noise — real sprints aren't exact replays
                // ±20% variance to simulate real-world fluctuation
                double noise = 1.0 + (ThreadLocalRandom.current().nextDouble() - 0.5) * 0.4;
                int simulatedVelocity = Math.max(1, (int) (velocity * noise));

                pointsLeft -= simulatedVelocity;
                sprints++;

                // Safety valve — cap at 100 sprints to prevent infinite loop
                if (sprints >= 100) break;
            }

            results[i] = sprints;
        }

        return results;
    }
}
