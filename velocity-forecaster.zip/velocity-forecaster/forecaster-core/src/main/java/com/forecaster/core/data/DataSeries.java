package com.forecaster.core.data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Generic numeric data series. Works with any Number subtype —
 * Integer for story points, Double for hours, Long for cycle time.
 *
 * <p>Bounded type parameter {@code T extends Number} gives us
 * {@code doubleValue()} on every element for math operations,
 * while preserving the original type for consumers.</p>
 *
 * @param <T> numeric type (Integer, Double, Long)
 */
public final class DataSeries<T extends Number> {

    private final List<T> values;

    private DataSeries(List<T> values) {
        this.values = Collections.unmodifiableList(new ArrayList<>(values));
    }

    public static <T extends Number> DataSeries<T> of(List<T> values) {
        if (values == null || values.isEmpty()) {
            throw new IllegalArgumentException("DataSeries requires at least one value");
        }
        return new DataSeries<>(values);
    }

    @SafeVarargs
    public static <T extends Number> DataSeries<T> of(T... values) {
        return of(List.of(values));
    }

    public List<T> getValues() { return values; }
    public int size() { return values.size(); }
    public T get(int index) { return values.get(index); }

    /**
     * Arithmetic mean. Uses doubleValue() — works regardless of T.
     */
    public double mean() {
        return values.stream()
                .mapToDouble(Number::doubleValue)
                .average()
                .orElse(0.0);
    }

    /**
     * Standard deviation — measures velocity consistency.
     * High std dev = unpredictable team. Low = stable.
     */
    public double standardDeviation() {
        double avg = mean();
        double variance = values.stream()
                .mapToDouble(Number::doubleValue)
                .map(v -> Math.pow(v - avg, 2))
                .average()
                .orElse(0.0);
        return Math.sqrt(variance);
    }

    /**
     * Minimum value in the series.
     */
    public double min() {
        return values.stream().mapToDouble(Number::doubleValue).min().orElse(0.0);
    }

    /**
     * Maximum value in the series.
     */
    public double max() {
        return values.stream().mapToDouble(Number::doubleValue).max().orElse(0.0);
    }

    /**
     * Percentile calculation. Used for confidence intervals.
     * p50 = median, p85 = 85th percentile, etc.
     *
     * @param percentile value between 0.0 and 1.0
     */
    public double percentile(double percentile) {
        if (percentile < 0.0 || percentile > 1.0) {
            throw new IllegalArgumentException("Percentile must be 0.0–1.0. Got: " + percentile);
        }
        List<Double> sorted = values.stream()
                .mapToDouble(Number::doubleValue)
                .sorted()
                .boxed()
                .collect(Collectors.toList());
        int index = (int) Math.ceil(percentile * sorted.size()) - 1;
        return sorted.get(Math.max(0, Math.min(index, sorted.size() - 1)));
    }

    /**
     * Last N values. For weighted-recent strategies that emphasize
     * recent sprints over historical ones.
     */
    public DataSeries<T> lastN(int n) {
        if (n >= values.size()) return this;
        return new DataSeries<>(values.subList(values.size() - n, values.size()));
    }

    /**
     * Weighted version — repeats recent values to give them more influence.
     * If weight=3, last value appears 3 times in the series.
     */
    public DataSeries<T> withRecentWeight(int weight) {
        if (weight <= 1) return this;
        List<T> weighted = new ArrayList<>(values);
        T lastValue = values.getLast();
        for (int i = 1; i < weight; i++) {
            weighted.add(lastValue);
        }
        return new DataSeries<>(weighted);
    }

    @Override
    public String toString() {
        return "DataSeries{size=%d, mean=%.1f, stdDev=%.1f}"
                .formatted(size(), mean(), standardDeviation());
    }
}
