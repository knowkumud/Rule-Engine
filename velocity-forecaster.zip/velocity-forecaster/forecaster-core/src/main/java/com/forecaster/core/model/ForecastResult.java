package com.forecaster.core.model;

import java.time.LocalDate;
import java.util.Collections;
import java.util.Map;

/**
 * Immutable forecast result with confidence intervals.
 *
 * <p>A forecast isn't just a date — it's a range.
 * "We'll finish between Sprint 5 and Sprint 8, with 85% confidence
 * it'll be done by Sprint 6." That's what this captures.</p>
 *
 * @param strategyName       which model produced this (e.g., "MONTE_CARLO")
 * @param estimatedSprints   expected number of sprints to complete
 * @param bestCase           optimistic estimate (low percentile)
 * @param worstCase          pessimistic estimate (high percentile)
 * @param estimatedDate      projected completion date
 * @param bestCaseDate       optimistic completion date
 * @param worstCaseDate      pessimistic completion date
 * @param confidenceLevel    confidence interval (e.g., 0.85 = 85%)
 * @param averageVelocity    velocity used for estimation
 * @param metadata           extra context (simulation count, std deviation, etc.)
 */
public record ForecastResult(
        String strategyName,
        int estimatedSprints,
        int bestCase,
        int worstCase,
        LocalDate estimatedDate,
        LocalDate bestCaseDate,
        LocalDate worstCaseDate,
        double confidenceLevel,
        double averageVelocity,
        Map<String, Object> metadata
) {

    /**
     * Defensive copy on metadata — prevents mutation after creation.
     */
    public ForecastResult {
        metadata = metadata == null
                ? Collections.emptyMap()
                : Collections.unmodifiableMap(metadata);
    }

    /**
     * Sprint range as a readable string.
     * Example: "5–8 sprints (85% confidence: by Sprint 6)"
     */
    public String toSummary() {
        return "%d–%d sprints (%.0f%% confidence: ~%d sprints, est. %s)"
                .formatted(bestCase, worstCase, confidenceLevel * 100,
                        estimatedSprints, estimatedDate);
    }
}
