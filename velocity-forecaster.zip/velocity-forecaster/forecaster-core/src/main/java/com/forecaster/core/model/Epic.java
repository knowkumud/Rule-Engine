package com.forecaster.core.model;

import java.util.Objects;

/**
 * An epic (body of work) being tracked for forecasting.
 * Immutable via private constructor + builder.
 */
public final class Epic {

    private final String id;
    private final String name;
    private final int totalPoints;
    private final int completedPoints;
    private final EpicStatus status;

    private Epic(Builder builder) {
        this.id = Objects.requireNonNull(builder.id, "Epic ID required");
        this.name = Objects.requireNonNull(builder.name, "Epic name required");
        this.totalPoints = builder.totalPoints;
        this.completedPoints = builder.completedPoints;
        this.status = builder.status;

        if (totalPoints < 0) throw new IllegalArgumentException("Total points cannot be negative");
        if (completedPoints < 0) throw new IllegalArgumentException("Completed points cannot be negative");
        if (completedPoints > totalPoints) throw new IllegalArgumentException("Completed cannot exceed total");
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public int getTotalPoints() { return totalPoints; }
    public int getCompletedPoints() { return completedPoints; }
    public EpicStatus getStatus() { return status; }

    /**
     * Remaining work to forecast against.
     */
    public int getRemainingPoints() {
        return totalPoints - completedPoints;
    }

    /**
     * Progress as a percentage (0.0 to 1.0).
     */
    public double getProgressPercent() {
        return totalPoints == 0 ? 0.0 : (double) completedPoints / totalPoints;
    }

    public boolean isComplete() {
        return status.isTerminal() || completedPoints >= totalPoints;
    }

    @Override
    public String toString() {
        return "Epic{id='%s', name='%s', progress=%d/%d (%s)}"
                .formatted(id, name, completedPoints, totalPoints, status);
    }

    public static Builder builder() { return new Builder(); }

    public Builder toBuilder() {
        return new Builder().id(id).name(name)
                .totalPoints(totalPoints).completedPoints(completedPoints).status(status);
    }

    public static final class Builder {
        private String id;
        private String name;
        private int totalPoints;
        private int completedPoints;
        private EpicStatus status = EpicStatus.BACKLOG;

        private Builder() {}

        public Builder id(String id) { this.id = id; return this; }
        public Builder name(String name) { this.name = name; return this; }
        public Builder totalPoints(int p) { this.totalPoints = p; return this; }
        public Builder completedPoints(int p) { this.completedPoints = p; return this; }
        public Builder status(EpicStatus s) { this.status = s; return this; }

        public Epic build() { return new Epic(this); }
    }
}
