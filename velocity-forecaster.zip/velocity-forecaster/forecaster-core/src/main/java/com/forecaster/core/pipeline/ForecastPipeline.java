package com.forecaster.core.pipeline;

import com.forecaster.core.data.DataSeries;
import com.forecaster.core.model.*;
import com.forecaster.core.strategy.ForecastStrategy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * TEMPLATE METHOD PATTERN: Defines the skeleton of the forecast algorithm.
 * Subclasses override specific steps without changing the overall flow.
 *
 * <p>Pipeline: gatherData() → validate() → normalize() → execute() → summarize()</p>
 *
 * <p>The {@code forecast()} method is {@code final} — subclasses CANNOT
 * change the step order. They can only customize individual steps.
 * This is the key difference between Template Method and Strategy:</p>
 * <ul>
 *   <li>Strategy: swap the ENTIRE algorithm</li>
 *   <li>Template Method: swap STEPS within a fixed algorithm</li>
 * </ul>
 */
public abstract class ForecastPipeline {

    private static final Logger log = LoggerFactory.getLogger(ForecastPipeline.class);

    /**
     * Template method — final so the pipeline order is enforced.
     * Subclasses override the protected hooks, not this method.
     */
    public final ForecastResult forecast(Epic epic, List<SprintSnapshot> history,
                                          ForecastStrategy strategy, SimulationConfig config) {
        log.debug("Pipeline start: {} with strategy {}", epic.getId(), strategy.getName());
        long start = System.nanoTime();

        // Step 1: Gather and prepare data
        List<SprintSnapshot> data = gatherData(history);

        // Step 2: Validate inputs
        validate(epic, data);

        // Step 3: Normalize data (remove outliers, etc.)
        List<SprintSnapshot> normalized = normalize(data);

        // Step 4: Execute the forecast strategy
        ForecastResult result = execute(epic, normalized, strategy, config);

        // Step 5: Post-process / summarize
        ForecastResult finalResult = summarize(result);

        long durationMs = (System.nanoTime() - start) / 1_000_000;
        log.info("Pipeline complete: {} → {} in {}ms",
                epic.getId(), result.toSummary(), durationMs);

        return finalResult;
    }

    // --- Hooks for subclasses to override ---

    /**
     * Gather sprint data. Default: use as-is.
     * Override to filter by date range, team, etc.
     */
    protected List<SprintSnapshot> gatherData(List<SprintSnapshot> history) {
        return history;
    }

    /**
     * Validate inputs before forecasting.
     * Override to add custom validation rules.
     */
    protected void validate(Epic epic, List<SprintSnapshot> data) {
        if (epic.isComplete()) {
            throw new IllegalArgumentException("Epic '%s' is already complete".formatted(epic.getName()));
        }
        if (data.isEmpty()) {
            throw new IllegalArgumentException("No sprint data available for forecasting");
        }
        if (data.size() < 3) {
            log.warn("Only {} sprints available — forecast will have low confidence", data.size());
        }
    }

    /**
     * Normalize data — remove outliers, etc.
     * Override to apply custom normalization.
     */
    protected List<SprintSnapshot> normalize(List<SprintSnapshot> data) {
        return data; // default: no normalization
    }

    /**
     * Execute the strategy. Rarely overridden — here for completeness.
     */
    protected ForecastResult execute(Epic epic, List<SprintSnapshot> data,
                                      ForecastStrategy strategy, SimulationConfig config) {
        return strategy.forecast(epic, data, config);
    }

    /**
     * Post-process the result. Override to add team-specific adjustments.
     */
    protected ForecastResult summarize(ForecastResult result) {
        return result; // default: no post-processing
    }
}
