package com.forecaster.core.strategy;

import com.forecaster.core.data.DataSeries;
import com.forecaster.core.model.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

/**
 * Weighted model: recent sprints count more than old ones.
 *
 * <p>If a team has been ramping up (new members, better tooling),
 * old velocity drags the average down. This strategy uses
 * {@link DataSeries#withRecentWeight(int)} to amplify recent data.</p>
 *
 * <p>This is the "trust recent performance" model.</p>
 */
public final class WeightedVelocityStrategy implements ForecastStrategy {

    @Override
    public String getName() { return "WEIGHTED_RECENT"; }

    @Override
    public ForecastResult forecast(Epic epic, List<SprintSnapshot> history, SimulationConfig config) {
        DataSeries<Integer> raw = DataSeries.of(
                history.stream().map(SprintSnapshot::velocity).toList()
        );

        // Take last 5 sprints, weight the most recent one 3x
        DataSeries<Integer> weighted = raw
                .lastN(5)
                .withRecentWeight(config.getRecentSprintWeight());

        double avgVelocity = weighted.mean();
        double stdDev = weighted.standardDeviation();
        int remaining = epic.getRemainingPoints();

        if (avgVelocity <= 0) {
            throw new IllegalArgumentException("Weighted velocity is zero — cannot forecast");
        }

        int estimatedSprints = (int) Math.ceil(remaining / avgVelocity);

        double optimistic = Math.max(1, avgVelocity + stdDev);
        double pessimistic = Math.max(1, avgVelocity - stdDev);
        int bestCase = (int) Math.ceil(remaining / optimistic);
        int worstCase = (int) Math.ceil(remaining / pessimistic);

        LocalDate today = LocalDate.now();
        int sprintDays = config.getSprintLengthDays();

        return new ForecastResult(
                getName(),
                estimatedSprints,
                bestCase,
                worstCase,
                today.plusDays((long) estimatedSprints * sprintDays),
                today.plusDays((long) bestCase * sprintDays),
                today.plusDays((long) worstCase * sprintDays),
                config.getConfidenceLevel(),
                avgVelocity,
                Map.of(
                        "recentWeight", config.getRecentSprintWeight(),
                        "sprintsUsed", Math.min(5, history.size()),
                        "standardDeviation", stdDev,
                        "remainingPoints", remaining
                )
        );
    }
}
