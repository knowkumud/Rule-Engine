package com.forecaster.core.pipeline;

import com.forecaster.core.data.DataSeries;
import com.forecaster.core.model.SprintSnapshot;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.List;

/**
 * Pipeline that removes outlier sprints before forecasting.
 *
 * <p>Overrides only {@code normalize()} — the Template Method ensures
 * gather → validate → normalize → execute → summarize order is preserved.</p>
 *
 * <p>Uses IQR (interquartile range) method: any sprint with velocity
 * outside [Q1 - 1.5*IQR, Q3 + 1.5*IQR] is excluded. This handles
 * holiday sprints (low velocity) and anomalous sprints (scope dumps).</p>
 */
public final class OutlierRemovingPipeline extends ForecastPipeline {

    private static final Logger log = LoggerFactory.getLogger(OutlierRemovingPipeline.class);

    @Override
    protected List<SprintSnapshot> normalize(List<SprintSnapshot> data) {
        if (data.size() < 4) {
            return data; // need enough data for meaningful IQR
        }

        DataSeries<Integer> velocities = DataSeries.of(
                data.stream().map(SprintSnapshot::velocity).toList()
        );

        double q1 = velocities.percentile(0.25);
        double q3 = velocities.percentile(0.75);
        double iqr = q3 - q1;
        double lowerBound = q1 - 1.5 * iqr;
        double upperBound = q3 + 1.5 * iqr;

        List<SprintSnapshot> filtered = data.stream()
                .filter(s -> s.velocity() >= lowerBound && s.velocity() <= upperBound)
                .toList();

        int removed = data.size() - filtered.size();
        if (removed > 0) {
            log.info("Removed {} outlier sprints (bounds: {:.0f}–{:.0f})",
                    removed, lowerBound, upperBound);
        }

        // Safety: never remove all data
        return filtered.isEmpty() ? data : filtered;
    }
}
