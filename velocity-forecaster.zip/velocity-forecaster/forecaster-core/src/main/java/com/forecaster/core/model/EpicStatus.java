package com.forecaster.core.model;

import java.util.Set;

/**
 * Epic lifecycle states with transition logic baked IN.
 *
 * <p>This is an enum that DOES things — not just a label.
 * {@code canTransitionTo()} enforces valid state transitions,
 * and {@code isTerminal()} / {@code isActive()} drive business logic.</p>
 */
public enum EpicStatus {

    BACKLOG(false) {
        @Override
        public Set<EpicStatus> allowedTransitions() {
            return Set.of(IN_PROGRESS, CANCELLED);
        }
    },
    IN_PROGRESS(false) {
        @Override
        public Set<EpicStatus> allowedTransitions() {
            return Set.of(ON_HOLD, COMPLETED, CANCELLED);
        }
    },
    ON_HOLD(false) {
        @Override
        public Set<EpicStatus> allowedTransitions() {
            return Set.of(IN_PROGRESS, CANCELLED);
        }
    },
    COMPLETED(true) {
        @Override
        public Set<EpicStatus> allowedTransitions() {
            return Set.of(); // terminal — no transitions out
        }
    },
    CANCELLED(true) {
        @Override
        public Set<EpicStatus> allowedTransitions() {
            return Set.of();
        }
    };

    private final boolean terminal;

    EpicStatus(boolean terminal) {
        this.terminal = terminal;
    }

    public boolean isTerminal() { return terminal; }

    public boolean isActive() { return !terminal; }

    /**
     * Valid next states from this state.
     * Each enum constant overrides this — polymorphism via enum.
     */
    public abstract Set<EpicStatus> allowedTransitions();

    /**
     * Validates a state transition. Throws if invalid.
     * This prevents illegal moves like COMPLETED → IN_PROGRESS.
     */
    public void validateTransition(EpicStatus target) {
        if (!allowedTransitions().contains(target)) {
            throw new IllegalStateException(
                    "Cannot transition from %s to %s. Allowed: %s"
                            .formatted(this, target, allowedTransitions()));
        }
    }

    public boolean canTransitionTo(EpicStatus target) {
        return allowedTransitions().contains(target);
    }
}
