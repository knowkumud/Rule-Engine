package com.forecaster.core;

import com.forecaster.core.data.DataSeries;
import com.forecaster.core.engine.ForecastEngine;
import com.forecaster.core.engine.ForecastEngine.ForecastComparison;
import com.forecaster.core.model.*;
import com.forecaster.core.pipeline.DefaultForecastPipeline;
import com.forecaster.core.strategy.*;
import org.junit.jupiter.api.*;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class VelocityForecasterTest {

    private List<SprintSnapshot> sampleHistory;
    private Epic sampleEpic;
    private SimulationConfig config;

    @BeforeEach
    void setUp() {
        sampleHistory = List.of(
                new SprintSnapshot("Sprint 1", LocalDate.of(2025, 1, 6), LocalDate.of(2025, 1, 17), 20, 18, 2),
                new SprintSnapshot("Sprint 2", LocalDate.of(2025, 1, 20), LocalDate.of(2025, 1, 31), 20, 22, 0),
                new SprintSnapshot("Sprint 3", LocalDate.of(2025, 2, 3), LocalDate.of(2025, 2, 14), 22, 20, 2),
                new SprintSnapshot("Sprint 4", LocalDate.of(2025, 2, 17), LocalDate.of(2025, 2, 28), 20, 19, 1),
                new SprintSnapshot("Sprint 5", LocalDate.of(2025, 3, 3), LocalDate.of(2025, 3, 14), 21, 24, 0),
                new SprintSnapshot("Sprint 6", LocalDate.of(2025, 3, 17), LocalDate.of(2025, 3, 28), 22, 21, 1)
        );

        sampleEpic = Epic.builder()
                .id("EPIC-001")
                .name("Customer Portal Redesign")
                .totalPoints(120)
                .completedPoints(40)
                .status(EpicStatus.IN_PROGRESS)
                .build();

        config = SimulationConfig.builder()
                .iterations(5_000)
                .confidenceLevel(0.85)
                .sprintLengthDays(14)
                .recentSprintWeight(3)
                .build();
    }

    // ========== EPIC STATUS ENUM TESTS ==========

    @Nested
    @DisplayName("EpicStatus — Enum with behavior")
    class EpicStatusTests {

        @Test
        @DisplayName("valid transitions are allowed")
        void validTransitions() {
            assertTrue(EpicStatus.BACKLOG.canTransitionTo(EpicStatus.IN_PROGRESS));
            assertTrue(EpicStatus.IN_PROGRESS.canTransitionTo(EpicStatus.COMPLETED));
            assertTrue(EpicStatus.IN_PROGRESS.canTransitionTo(EpicStatus.ON_HOLD));
        }

        @Test
        @DisplayName("invalid transitions throw IllegalStateException")
        void invalidTransitions() {
            assertThrows(IllegalStateException.class,
                    () -> EpicStatus.COMPLETED.validateTransition(EpicStatus.IN_PROGRESS));
        }

        @Test
        @DisplayName("terminal states have no transitions")
        void terminalStates() {
            assertTrue(EpicStatus.COMPLETED.isTerminal());
            assertTrue(EpicStatus.COMPLETED.allowedTransitions().isEmpty());
            assertFalse(EpicStatus.IN_PROGRESS.isTerminal());
        }
    }

    // ========== DATA SERIES GENERICS TESTS ==========

    @Nested
    @DisplayName("DataSeries<T> — Generics")
    class DataSeriesTests {

        @Test
        @DisplayName("works with Integer type")
        void integerSeries() {
            DataSeries<Integer> series = DataSeries.of(10, 20, 30, 40);
            assertEquals(25.0, series.mean());
            assertEquals(4, series.size());
        }

        @Test
        @DisplayName("works with Double type")
        void doubleSeries() {
            DataSeries<Double> series = DataSeries.of(1.5, 2.5, 3.5);
            assertEquals(2.5, series.mean(), 0.01);
        }

        @Test
        @DisplayName("calculates standard deviation")
        void standardDeviation() {
            DataSeries<Integer> stable = DataSeries.of(20, 20, 20, 20);
            DataSeries<Integer> volatile_ = DataSeries.of(5, 35, 10, 30);

            assertEquals(0.0, stable.standardDeviation());
            assertTrue(volatile_.standardDeviation() > stable.standardDeviation());
        }

        @Test
        @DisplayName("percentile calculation for confidence intervals")
        void percentile() {
            DataSeries<Integer> series = DataSeries.of(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
            assertEquals(1.0, series.percentile(0.1));
            assertEquals(5.0, series.percentile(0.5));
            assertEquals(9.0, series.percentile(0.9));
        }

        @Test
        @DisplayName("lastN returns recent values")
        void lastN() {
            DataSeries<Integer> series = DataSeries.of(10, 20, 30, 40, 50);
            DataSeries<Integer> last3 = series.lastN(3);
            assertEquals(3, last3.size());
            assertEquals(40.0, last3.mean());
        }

        @Test
        @DisplayName("withRecentWeight amplifies last value")
        void recentWeight() {
            DataSeries<Integer> series = DataSeries.of(10, 20, 30);
            DataSeries<Integer> weighted = series.withRecentWeight(3);
            // [10, 20, 30, 30, 30] → mean should shift toward 30
            assertEquals(5, weighted.size());
            assertTrue(weighted.mean() > series.mean());
        }

        @Test
        @DisplayName("rejects empty data")
        void rejectsEmpty() {
            assertThrows(IllegalArgumentException.class,
                    () -> DataSeries.of(List.of()));
        }
    }

    // ========== STRATEGY TESTS ==========

    @Nested
    @DisplayName("Forecast Strategies")
    class StrategyTests {

        @Test
        @DisplayName("AverageVelocity returns reasonable estimate")
        void averageVelocity() {
            ForecastResult result = new AverageVelocityStrategy()
                    .forecast(sampleEpic, sampleHistory, config);

            assertEquals("AVERAGE_VELOCITY", result.strategyName());
            assertTrue(result.estimatedSprints() > 0);
            assertTrue(result.bestCase() <= result.estimatedSprints());
            assertTrue(result.worstCase() >= result.estimatedSprints());
            assertTrue(result.averageVelocity() > 0);
        }

        @Test
        @DisplayName("WeightedRecent emphasizes recent sprints")
        void weightedRecent() {
            ForecastResult result = new WeightedVelocityStrategy()
                    .forecast(sampleEpic, sampleHistory, config);

            assertEquals("WEIGHTED_RECENT", result.strategyName());
            assertTrue(result.estimatedSprints() > 0);
            assertNotNull(result.metadata().get("recentWeight"));
        }

        @Test
        @DisplayName("MonteCarlo produces confidence intervals")
        void monteCarlo() {
            ForecastResult result = new MonteCarloStrategy()
                    .forecast(sampleEpic, sampleHistory, config);

            assertEquals("MONTE_CARLO", result.strategyName());
            assertTrue(result.bestCase() <= result.estimatedSprints());
            assertTrue(result.worstCase() >= result.estimatedSprints());
            assertNotNull(result.metadata().get("p50"));
            assertNotNull(result.metadata().get("p90"));
        }

        @Test
        @DisplayName("all strategies handle small history")
        void smallHistory() {
            List<SprintSnapshot> twoSprints = sampleHistory.subList(0, 2);

            assertDoesNotThrow(() ->
                    new AverageVelocityStrategy().forecast(sampleEpic, twoSprints, config));
            assertDoesNotThrow(() ->
                    new MonteCarloStrategy().forecast(sampleEpic, twoSprints, config));
        }
    }

    // ========== ENGINE PARALLEL EXECUTION TESTS ==========

    @Nested
    @DisplayName("ForecastEngine — Parallel execution")
    class EngineTests {

        @Test
        @DisplayName("runs all strategies and returns comparison")
        void forecastAll() {
            ForecastEngine engine = ForecastEngine.builder()
                    .addStrategy(new AverageVelocityStrategy())
                    .addStrategy(new WeightedVelocityStrategy())
                    .addStrategy(new MonteCarloStrategy())
                    .pipeline(new DefaultForecastPipeline())
                    .build();

            ForecastComparison comparison = engine.forecastAll(sampleEpic, sampleHistory, config);

            assertEquals(3, comparison.results().size());
            assertTrue(comparison.consensusSprints() > 0);
            assertTrue(comparison.mostConservative().isPresent());
            assertTrue(comparison.mostOptimistic().isPresent());
        }

        @Test
        @DisplayName("forecastWith returns single strategy result")
        void forecastWithSingleStrategy() {
            ForecastEngine engine = ForecastEngine.builder()
                    .addStrategy(new AverageVelocityStrategy())
                    .addStrategy(new MonteCarloStrategy())
                    .build();

            var result = engine.forecastWith("MONTE_CARLO", sampleEpic, sampleHistory, config);

            assertTrue(result.isPresent());
            assertEquals("MONTE_CARLO", result.get().strategyName());
        }

        @Test
        @DisplayName("returns empty for unknown strategy")
        void unknownStrategy() {
            ForecastEngine engine = ForecastEngine.builder()
                    .addStrategy(new AverageVelocityStrategy())
                    .build();

            assertTrue(engine.forecastWith("NONEXISTENT", sampleEpic, sampleHistory, config).isEmpty());
        }

        @Test
        @DisplayName("lists available strategies")
        void availableStrategies() {
            ForecastEngine engine = ForecastEngine.builder()
                    .addStrategy(new AverageVelocityStrategy())
                    .addStrategy(new MonteCarloStrategy())
                    .build();

            assertEquals(List.of("AVERAGE_VELOCITY", "MONTE_CARLO"), engine.getAvailableStrategies());
        }

        @Test
        @DisplayName("builder rejects empty strategy list")
        void rejectsNoStrategies() {
            assertThrows(IllegalStateException.class,
                    () -> ForecastEngine.builder().build());
        }
    }

    // ========== IMMUTABILITY TESTS ==========

    @Nested
    @DisplayName("Immutability")
    class ImmutabilityTests {

        @Test
        @DisplayName("SprintSnapshot validates on construction")
        void snapshotValidation() {
            assertThrows(IllegalArgumentException.class, () ->
                    new SprintSnapshot("bad", LocalDate.now(), LocalDate.now().minusDays(1), 10, 10, 0));
        }

        @Test
        @DisplayName("Epic.toBuilder creates independent copy")
        void epicCopy() {
            Epic copy = sampleEpic.toBuilder().completedPoints(60).build();

            assertEquals(40, sampleEpic.getCompletedPoints());
            assertEquals(60, copy.getCompletedPoints());
        }

        @Test
        @DisplayName("ForecastResult metadata is unmodifiable")
        void resultImmutability() {
            ForecastResult result = new AverageVelocityStrategy()
                    .forecast(sampleEpic, sampleHistory, config);

            assertThrows(UnsupportedOperationException.class,
                    () -> result.metadata().put("hack", "value"));
        }

        @Test
        @DisplayName("SimulationConfig validates bounds")
        void configValidation() {
            assertThrows(IllegalStateException.class, () ->
                    SimulationConfig.builder().iterations(0).build());
            assertThrows(IllegalStateException.class, () ->
                    SimulationConfig.builder().confidenceLevel(1.5).build());
        }
    }

    // ========== PIPELINE TESTS ==========

    @Nested
    @DisplayName("Forecast Pipeline")
    class PipelineTests {

        @Test
        @DisplayName("rejects completed epics")
        void rejectsCompletedEpic() {
            Epic done = Epic.builder()
                    .id("E2").name("Done").totalPoints(10).completedPoints(10)
                    .status(EpicStatus.COMPLETED).build();

            assertThrows(IllegalArgumentException.class, () ->
                    new DefaultForecastPipeline().forecast(
                            done, sampleHistory, new AverageVelocityStrategy(), config));
        }

        @Test
        @DisplayName("rejects empty history")
        void rejectsEmptyHistory() {
            assertThrows(IllegalArgumentException.class, () ->
                    new DefaultForecastPipeline().forecast(
                            sampleEpic, List.of(), new AverageVelocityStrategy(), config));
        }
    }
}
