package com.ruleengine.store.cache;

import com.ruleengine.core.model.Ticket;
import com.ruleengine.core.rule.Rule;
import com.ruleengine.store.service.RuleCacheService;
import com.github.benmanes.caffeine.cache.Cache;
import com.github.benmanes.caffeine.cache.Caffeine;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Supplier;

/**
 * Caffeine-backed rule cache. Rules are cached in memory to avoid
 * hitting the database on every ticket evaluation.
 *
 * <p>Invalidation strategy: explicit invalidation on every write operation
 * (create, update, rollback, toggle). TTL is a safety net for edge cases.</p>
 *
 * <p>Why Caffeine over Redis: Rules are read-heavy, change rarely, and are
 * small enough to fit in heap. Local cache eliminates network hop.</p>
 */
@Component
public class CaffeineRuleCacheService implements RuleCacheService {

    private static final Logger log = LoggerFactory.getLogger(CaffeineRuleCacheService.class);
    private static final String RULES_KEY = "active_rules";

    private final Cache<String, List<Rule<Ticket>>> cache;

    public CaffeineRuleCacheService() {
        this.cache = Caffeine.newBuilder()
                .maximumSize(1) // single entry — the full rule set
                .expireAfterWrite(5, TimeUnit.MINUTES) // safety TTL
                .recordStats() // for metrics
                .build();
    }

    @Override
    public List<Rule<Ticket>> getOrLoad(Supplier<List<Rule<Ticket>>> loader) {
        List<Rule<Ticket>> cached = cache.getIfPresent(RULES_KEY);
        if (cached != null) {
            log.trace("Cache HIT — {} rules", cached.size());
            return cached;
        }

        log.debug("Cache MISS — loading rules from database");
        List<Rule<Ticket>> rules = loader.get();
        cache.put(RULES_KEY, rules);
        log.info("Cached {} active rules", rules.size());
        return rules;
    }

    @Override
    public void invalidate() {
        cache.invalidateAll();
        log.info("Rule cache invalidated");
    }

    /**
     * Cache stats for metrics endpoint.
     */
    public CacheStats getStats() {
        var stats = cache.stats();
        return new CacheStats(
                stats.hitCount(),
                stats.missCount(),
                stats.hitRate(),
                stats.evictionCount()
        );
    }

    public record CacheStats(long hits, long misses, double hitRate, long evictions) {}
}
