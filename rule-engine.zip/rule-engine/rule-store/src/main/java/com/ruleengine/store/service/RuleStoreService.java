package com.ruleengine.store.service;

import com.ruleengine.core.model.Ticket;
import com.ruleengine.core.pattern.interpreter.ExpressionParser;
import com.ruleengine.core.pattern.interpreter.ExpressionRule;
import com.ruleengine.core.rule.Rule;
import com.ruleengine.store.entity.RuleEntity;
import com.ruleengine.store.repository.RuleRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * Service layer for rule CRUD operations with versioning.
 *
 * <p>Key production behaviors:</p>
 * <ul>
 *   <li>Every update creates a new version (append-only for audit trail)</li>
 *   <li>Rollback restores a previous version as the new current</li>
 *   <li>Expression validation happens BEFORE persistence</li>
 *   <li>Cache invalidation on every write operation</li>
 * </ul>
 */
@Service
public class RuleStoreService {

    private static final Logger log = LoggerFactory.getLogger(RuleStoreService.class);

    private final RuleRepository repository;
    private final RuleCacheService cacheService;

    public RuleStoreService(RuleRepository repository, RuleCacheService cacheService) {
        this.repository = repository;
        this.cacheService = cacheService;
    }

    /**
     * Create a new rule. Validates the expression before saving.
     *
     * @throws ExpressionParser.ExpressionParseException if expression is invalid
     */
    @Transactional
    public RuleEntity createRule(String externalId, String name, String expression,
                                  String action, int priority, String createdBy) {
        // Validate expression BEFORE touching the database
        ExpressionParser.parse(expression);

        RuleEntity entity = new RuleEntity();
        entity.setExternalId(externalId);
        entity.setName(name);
        entity.setExpression(expression);
        entity.setAction(action);
        entity.setPriority(priority);
        entity.setVersion(1);
        entity.setCurrent(true);
        entity.setCreatedBy(createdBy);

        RuleEntity saved = repository.save(entity);
        cacheService.invalidate();

        log.info("Created rule {} v1: '{}'", externalId, expression);
        return saved;
    }

    /**
     * Update a rule. Creates a new version while retaining history.
     * The old version is marked as non-current.
     */
    @Transactional
    public RuleEntity updateRule(String externalId, String name, String expression,
                                  String action, int priority, String updatedBy) {
        // Validate new expression
        ExpressionParser.parse(expression);

        RuleEntity current = repository.findByExternalIdAndCurrentTrue(externalId)
                .orElseThrow(() -> new RuleNotFoundException(externalId));

        int nextVersion = current.getVersion() + 1;

        // Mark all existing versions as non-current
        repository.markAllVersionsNonCurrent(externalId);

        // Create new version
        RuleEntity newVersion = new RuleEntity();
        newVersion.setExternalId(externalId);
        newVersion.setName(name);
        newVersion.setExpression(expression);
        newVersion.setAction(action);
        newVersion.setPriority(priority);
        newVersion.setVersion(nextVersion);
        newVersion.setCurrent(true);
        newVersion.setActive(current.isActive());
        newVersion.setCreatedBy(updatedBy);

        RuleEntity saved = repository.save(newVersion);
        cacheService.invalidate();

        log.info("Updated rule {} to v{}: '{}'", externalId, nextVersion, expression);
        return saved;
    }

    /**
     * Rollback a rule to a specific version. Creates it as the newest version
     * (we don't mutate history — we copy the old version forward).
     */
    @Transactional
    public RuleEntity rollback(String externalId, int targetVersion, String rolledBackBy) {
        RuleEntity target = repository.findByExternalIdAndVersion(externalId, targetVersion)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Version %d not found for rule %s".formatted(targetVersion, externalId)));

        RuleEntity current = repository.findByExternalIdAndCurrentTrue(externalId)
                .orElseThrow(() -> new RuleNotFoundException(externalId));

        int nextVersion = current.getVersion() + 1;

        repository.markAllVersionsNonCurrent(externalId);

        // Copy target version as new current
        RuleEntity rollbackVersion = new RuleEntity();
        rollbackVersion.setExternalId(externalId);
        rollbackVersion.setName(target.getName());
        rollbackVersion.setExpression(target.getExpression());
        rollbackVersion.setAction(target.getAction());
        rollbackVersion.setPriority(target.getPriority());
        rollbackVersion.setVersion(nextVersion);
        rollbackVersion.setCurrent(true);
        rollbackVersion.setActive(target.isActive());
        rollbackVersion.setCreatedBy(rolledBackBy);

        RuleEntity saved = repository.save(rollbackVersion);
        cacheService.invalidate();

        log.info("Rolled back rule {} to v{} (now v{})", externalId, targetVersion, nextVersion);
        return saved;
    }

    /**
     * Toggle rule active status without creating a new version.
     */
    @Transactional
    public RuleEntity toggleActive(String externalId) {
        RuleEntity current = repository.findByExternalIdAndCurrentTrue(externalId)
                .orElseThrow(() -> new RuleNotFoundException(externalId));

        current.setActive(!current.isActive());
        RuleEntity saved = repository.save(current);
        cacheService.invalidate();

        log.info("Toggled rule {} active={}", externalId, saved.isActive());
        return saved;
    }

    /**
     * Load all active rules as executable Rule objects.
     * Uses cache — only hits DB on cache miss.
     */
    public List<Rule<Ticket>> loadActiveRules() {
        return cacheService.getOrLoad(() ->
                repository.findByCurrentTrueAndActiveTrue().stream()
                        .map(this::toRule)
                        .toList()
        );
    }

    /**
     * Get version history for admin UI.
     */
    @Transactional(readOnly = true)
    public List<RuleEntity> getVersionHistory(String externalId) {
        return repository.findByExternalIdOrderByVersionDesc(externalId);
    }

    /**
     * Get current version of a rule.
     */
    @Transactional(readOnly = true)
    public Optional<RuleEntity> getCurrentVersion(String externalId) {
        return repository.findByExternalIdAndCurrentTrue(externalId);
    }

    /**
     * Convert JPA entity to executable Rule.
     */
    private Rule<Ticket> toRule(RuleEntity entity) {
        return ExpressionRule.builder()
                .id(entity.getExternalId())
                .name(entity.getName())
                .description(entity.getDescription())
                .expressionString(entity.getExpression())
                .action(entity.getAction())
                .priority(entity.getPriority())
                .active(entity.isActive())
                .build();
    }

    public static class RuleNotFoundException extends RuntimeException {
        public RuleNotFoundException(String externalId) {
            super("Rule not found: " + externalId);
        }
    }
}
