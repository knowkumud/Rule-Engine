package com.ruleengine.store.entity;

import jakarta.persistence.*;
import java.time.Instant;

/**
 * JPA entity for persisting rules. Supports versioning — every update
 * creates a new version while retaining history for rollback.
 *
 * <p>Design decision: The rule expression is stored as a plain string,
 * not as a JSON blob of the AST. This keeps storage simple and makes
 * the expression parser the single source of truth for interpretation.</p>
 */
@Entity
@Table(name = "rules", indexes = {
        @Index(name = "idx_rule_external_id", columnList = "externalId"),
        @Index(name = "idx_rule_active", columnList = "active"),
        @Index(name = "idx_rule_version", columnList = "externalId, version")
})
public class RuleEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Business-facing rule ID (e.g., "R001"). Separate from DB primary key
     * so versions of the same rule share an externalId.
     */
    @Column(nullable = false)
    private String externalId;

    @Column(nullable = false)
    private String name;

    @Column(length = 1000)
    private String description;

    /**
     * The rule expression string. Parsed at load time by ExpressionParser.
     * Example: "category == 'network' AND priority == 'HIGH'"
     */
    @Column(nullable = false, length = 2000)
    private String expression;

    /**
     * The action to take when this rule matches (e.g., "route-to-netops").
     */
    @Column(nullable = false)
    private String action;

    @Column(nullable = false)
    private int priority;

    @Column(nullable = false)
    private boolean active = true;

    /**
     * Version number. Monotonically increasing per externalId.
     * Version 1 is the initial creation.
     */
    @Column(nullable = false)
    private int version = 1;

    /**
     * Whether this is the current (latest) version.
     * Only one version per externalId should have current=true.
     */
    @Column(nullable = false)
    private boolean current = true;

    @Column(nullable = false)
    private String createdBy;

    @Column(nullable = false)
    private Instant createdAt;

    @Column
    private Instant updatedAt;

    @PrePersist
    protected void onCreate() {
        createdAt = Instant.now();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = Instant.now();
    }

    // --- Getters and Setters ---

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getExternalId() { return externalId; }
    public void setExternalId(String externalId) { this.externalId = externalId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getExpression() { return expression; }
    public void setExpression(String expression) { this.expression = expression; }

    public String getAction() { return action; }
    public void setAction(String action) { this.action = action; }

    public int getPriority() { return priority; }
    public void setPriority(int priority) { this.priority = priority; }

    public boolean isActive() { return active; }
    public void setActive(boolean active) { this.active = active; }

    public int getVersion() { return version; }
    public void setVersion(int version) { this.version = version; }

    public boolean isCurrent() { return current; }
    public void setCurrent(boolean current) { this.current = current; }

    public String getCreatedBy() { return createdBy; }
    public void setCreatedBy(String createdBy) { this.createdBy = createdBy; }

    public Instant getCreatedAt() { return createdAt; }
    public Instant getUpdatedAt() { return updatedAt; }
}
