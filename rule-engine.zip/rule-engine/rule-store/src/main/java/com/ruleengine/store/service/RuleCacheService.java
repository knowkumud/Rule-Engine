package com.ruleengine.store.service;

import com.ruleengine.core.model.Ticket;
import com.ruleengine.core.rule.Rule;

import java.util.List;
import java.util.function.Supplier;

/**
 * Abstraction over rule caching. Allows swapping implementations
 * (Caffeine, Redis, no-op for tests) without changing service code.
 */
public interface RuleCacheService {

    /**
     * Get cached rules, or load from supplier on cache miss.
     */
    List<Rule<Ticket>> getOrLoad(Supplier<List<Rule<Ticket>>> loader);

    /**
     * Invalidate the entire rule cache. Called on every write operation.
     */
    void invalidate();
}
