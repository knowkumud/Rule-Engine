package com.ruleengine.store.repository;

import com.ruleengine.store.entity.RuleEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface RuleRepository extends JpaRepository<RuleEntity, Long> {

    /**
     * Load all current, active rules. This is what the engine evaluates against.
     */
    List<RuleEntity> findByCurrentTrueAndActiveTrue();

    /**
     * Load all current rules (active + inactive) for admin UI.
     */
    List<RuleEntity> findByCurrentTrue();

    /**
     * Find the current version of a specific rule.
     */
    Optional<RuleEntity> findByExternalIdAndCurrentTrue(String externalId);

    /**
     * Get version history for a rule (all versions, ordered).
     */
    List<RuleEntity> findByExternalIdOrderByVersionDesc(String externalId);

    /**
     * Find a specific version of a rule.
     */
    Optional<RuleEntity> findByExternalIdAndVersion(String externalId, int version);

    /**
     * Mark all versions of a rule as non-current.
     * Called before inserting a new version as current.
     */
    @Modifying
    @Query("UPDATE RuleEntity r SET r.current = false WHERE r.externalId = :externalId")
    void markAllVersionsNonCurrent(@Param("externalId") String externalId);

    /**
     * Count active rules for health check / metrics.
     */
    long countByCurrentTrueAndActiveTrue();
}
