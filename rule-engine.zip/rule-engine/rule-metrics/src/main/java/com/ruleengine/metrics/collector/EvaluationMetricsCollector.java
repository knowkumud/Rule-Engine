package com.ruleengine.metrics.collector;

import com.ruleengine.core.model.EvaluationContext;
import com.ruleengine.core.model.RuleResult;
import io.micrometer.core.instrument.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.util.concurrent.TimeUnit;

/**
 * Collects Micrometer metrics from rule evaluations.
 * Exposed via /actuator/prometheus for Grafana dashboards.
 *
 * <p>Metrics tracked:</p>
 * <ul>
 *   <li>rule_evaluation_total — counter of evaluations by result (match/no_match)</li>
 *   <li>rule_evaluation_duration — histogram of evaluation latency</li>
 *   <li>rule_hit_total — per-rule hit counter (which rules fire most?)</li>
 *   <li>rule_conflict_total — how often multiple rules match</li>
 *   <li>rule_fallback_total — how often default action is used</li>
 * </ul>
 */
@Component
public class EvaluationMetricsCollector {

    private static final Logger log = LoggerFactory.getLogger(EvaluationMetricsCollector.class);

    private final Counter evaluationCounter;
    private final Counter conflictCounter;
    private final Counter fallbackCounter;
    private final Timer evaluationTimer;
    private final MeterRegistry registry;

    public EvaluationMetricsCollector(MeterRegistry registry) {
        this.registry = registry;

        this.evaluationCounter = Counter.builder("rule_evaluation_total")
                .description("Total rule evaluations")
                .register(registry);

        this.conflictCounter = Counter.builder("rule_conflict_total")
                .description("Evaluations where multiple rules matched")
                .register(registry);

        this.fallbackCounter = Counter.builder("rule_fallback_total")
                .description("Evaluations using default fallback action")
                .register(registry);

        this.evaluationTimer = Timer.builder("rule_evaluation_duration")
                .description("Rule evaluation latency")
                .publishPercentiles(0.5, 0.95, 0.99) // p50, p95, p99
                .register(registry);
    }

    /**
     * Record metrics from a completed evaluation.
     * Call this after every engine.evaluate() — typically via AOP or event listener.
     */
    public <T> void record(EvaluationContext<T> context) {
        evaluationCounter.increment();

        evaluationTimer.record(context.totalEvaluationTimeMs(), TimeUnit.MILLISECONDS);

        if (context.getConflictCount() > 0) {
            conflictCounter.increment();
        }

        if (context.hasMatch() && "DEFAULT".equals(context.winningResult().ruleId())) {
            fallbackCounter.increment();
        }

        // Per-rule hit counters
        for (RuleResult<T> result : context.allResults()) {
            Counter.builder("rule_hit_total")
                    .tag("rule_id", result.ruleId())
                    .tag("matched", String.valueOf(result.isMatched()))
                    .register(registry)
                    .increment();
        }

        // Structured log for correlation
        if (context.hasMatch()) {
            log.info("evaluation_id={} matched_rule={} action={} conflicts={} duration_ms={} dry_run={}",
                    context.evaluationId(),
                    context.winningResult().ruleId(),
                    context.winningResult().action(),
                    context.getConflictCount(),
                    context.totalEvaluationTimeMs(),
                    context.dryRun());
        } else {
            log.warn("evaluation_id={} no_match=true duration_ms={} dry_run={}",
                    context.evaluationId(),
                    context.totalEvaluationTimeMs(),
                    context.dryRun());
        }
    }
}
