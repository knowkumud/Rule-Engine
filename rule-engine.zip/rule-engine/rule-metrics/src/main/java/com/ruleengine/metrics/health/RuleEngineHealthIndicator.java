package com.ruleengine.metrics.health;

import com.ruleengine.store.repository.RuleRepository;
import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;

/**
 * Custom health indicator exposed at /actuator/health.
 * Reports rule engine status including active rule count.
 *
 * <p>Returns DOWN if no active rules exist (likely a config issue)
 * or if the database is unreachable.</p>
 */
@Component
public class RuleEngineHealthIndicator implements HealthIndicator {

    private final RuleRepository repository;

    public RuleEngineHealthIndicator(RuleRepository repository) {
        this.repository = repository;
    }

    @Override
    public Health health() {
        try {
            long activeRules = repository.countByCurrentTrueAndActiveTrue();

            if (activeRules == 0) {
                return Health.down()
                        .withDetail("reason", "No active rules configured")
                        .withDetail("activeRules", 0)
                        .build();
            }

            return Health.up()
                    .withDetail("activeRules", activeRules)
                    .build();

        } catch (Exception e) {
            return Health.down()
                    .withDetail("reason", "Database unreachable")
                    .withException(e)
                    .build();
        }
    }
}
