# Rule Engine for ITSM Ticket Classification

A production-grade, configurable rule engine where business users define routing rules
(`if category=network AND priority=high → assign to NetOps`) without code changes.

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        rule-api (Spring Boot)                    │
│  REST Controllers │ OpenAPI/Swagger │ Global Exception Handler   │
├──────────┬────────┴─────────┬───────────────────────────────────┤
│ rule-store                  │ rule-metrics                       │
│ JPA + Versioning            │ Micrometer + Prometheus            │
│ Caffeine Cache              │ Health Indicators                  │
├─────────────────────────────┴───────────────────────────────────┤
│                     rule-core (Zero Dependencies)                │
│  RuleEngine<T> │ Expression Parser │ Composite │ Conflict Detect │
├─────────────────────────────────────────────────────────────────┤
│                     rule-integration                             │
│           Kafka Consumer │ Webhook Handler                       │
└─────────────────────────────────────────────────────────────────┘
```

## Design Patterns Demonstrated

| Pattern | Where | Why |
|---------|-------|-----|
| **Interpreter** | `ExpressionParser` → AST | Parse business rule strings into executable logic |
| **Composite** | `CompositeRule<T>` | Nest AND/OR rule groups arbitrarily deep |
| **Builder** | `Ticket.Builder`, `ExpressionRule.Builder`, `RuleEngine.Builder` | Fluent, validated object construction |
| **Strategy** | `ConflictResolutionStrategy` enum | Pluggable conflict resolution (priority, first-match, weighted) |
| **Factory** | `RuleResult.match()` / `RuleResult.noMatch()` | Controlled result creation with metadata |

## Java Engineering Highlights

- **Generics**: `Rule<T>`, `RuleEngine<T>`, `RuleResult<T>` — engine works on any entity type
- **Sealed interfaces**: `Expression` sealed hierarchy for exhaustive pattern matching
- **Records**: Immutable DTOs and results (`RuleResult`, `EvaluationContext`, `Ticket`)
- **CompletableFuture**: Parallel rule evaluation with timeout protection
- **Functional interfaces**: `Rule<T> extends Predicate<T>` — rules compose with `and()`/`or()`
- **Defensive immutability**: Unmodifiable collections, defensive copies in records

## Quick Start

```bash
# Local dev (H2 in-memory)
cd rule-api
mvn spring-boot:run

# Docker (PostgreSQL + Kafka)
docker-compose up -d
```

## API Usage

### Create a Rule
```bash
curl -X POST http://localhost:8080/api/v1/rules \
  -H "Content-Type: application/json" \
  -d '{
    "id": "R001",
    "name": "High-priority network tickets",
    "expression": "category == '\''network'\'' AND priority == '\''HIGH'\''",
    "action": "route-to-netops",
    "priority": 1
  }'
```

### Evaluate a Ticket
```bash
curl -X POST http://localhost:8080/api/v1/rules/evaluate \
  -H "Content-Type: application/json" \
  -d '{
    "ticketId": "INC001",
    "category": "network",
    "priority": "HIGH",
    "source": "monitoring",
    "description": "Firewall alerts on prod-fw-01",
    "dryRun": false
  }'
```

### Dry-Run (test rules without routing)
```bash
curl -X POST http://localhost:8080/api/v1/rules/evaluate \
  -d '{ "ticketId": "TEST", "category": "network", "priority": "HIGH", "dryRun": true }'
```

### Validate an Expression
```bash
curl -X POST http://localhost:8080/api/v1/rules/validate \
  -d '{ "expression": "category == '\''network'\'' AND priority == '\''HIGH'\''" }'
```

### Detect Conflicts
```bash
curl http://localhost:8080/api/v1/rules/conflicts
```

### Rollback a Rule
```bash
curl -X POST http://localhost:8080/api/v1/rules/R001/rollback \
  -d '{ "targetVersion": 1 }'
```

## Observability

- **Health**: `GET /actuator/health` — rule engine status + active rule count
- **Metrics**: `GET /actuator/prometheus` — evaluation latency, rule hit rates, conflicts
- **Swagger**: `GET /swagger-ui.html` — interactive API docs

## Project Structure

```
rule-engine/
├── rule-core/          ← Pure Java. Patterns, generics, engine. Zero Spring.
├── rule-store/         ← JPA persistence, versioning, Caffeine caching
├── rule-metrics/       ← Micrometer metrics, Prometheus, health checks
├── rule-api/           ← Spring Boot REST, OpenAPI, exception handling
├── rule-integration/   ← Kafka consumer, webhook handler
├── docker-compose.yml  ← PostgreSQL + Kafka for local dev
└── Dockerfile          ← Multi-stage build, JVM-tuned
```

## Running Tests

```bash
mvn test                    # unit tests
mvn verify                  # unit + integration tests
```
