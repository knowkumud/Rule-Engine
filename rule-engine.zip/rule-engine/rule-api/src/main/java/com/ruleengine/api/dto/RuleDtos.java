package com.ruleengine.api.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

import java.time.Instant;
import java.util.List;
import java.util.Map;

/**
 * API DTOs. Records for immutability and minimal boilerplate.
 * Validation annotations provide clear error messages for API consumers.
 */
public final class RuleDtos {

    private RuleDtos() {} // namespace class

    // --- Rule CRUD ---

    public record CreateRuleRequest(
            @NotBlank(message = "Rule ID is required") String id,
            @NotBlank(message = "Rule name is required") String name,
            String description,
            @NotBlank(message = "Expression is required") String expression,
            @NotBlank(message = "Action is required") String action,
            @Min(value = 1, message = "Priority must be >= 1") int priority
    ) {}

    public record UpdateRuleRequest(
            @NotBlank String name,
            String description,
            @NotBlank String expression,
            @NotBlank String action,
            @Min(1) int priority
    ) {}

    public record RuleResponse(
            String id,
            String name,
            String description,
            String expression,
            String action,
            int priority,
            boolean active,
            int version,
            Instant createdAt
    ) {}

    // --- Evaluation ---

    public record EvaluateRequest(
            @NotBlank String ticketId,
            @NotNull String category,
            String subcategory,
            @NotNull String priority,
            String source,
            String description,
            Map<String, String> customFields,
            boolean dryRun
    ) {}

    public record EvaluateResponse(
            String evaluationId,
            boolean matched,
            String winningRuleId,
            String winningRuleName,
            String action,
            int conflictCount,
            String strategyUsed,
            boolean dryRun,
            long evaluationTimeMs,
            List<RuleMatchDetail> allMatches
    ) {}

    public record RuleMatchDetail(
            String ruleId,
            String ruleName,
            boolean matched,
            String action,
            int priority,
            long evaluationTimeMs
    ) {}

    // --- Rollback ---

    public record RollbackRequest(
            @Min(1) int targetVersion
    ) {}

    // --- Conflict Detection ---

    public record ConflictReport(
            int totalConflicts,
            List<ConflictDetail> conflicts
    ) {}

    public record ConflictDetail(
            String type,
            List<String> involvedRuleIds,
            String description
    ) {}

    // --- Validation ---

    public record ValidateExpressionRequest(
            @NotBlank String expression
    ) {}

    public record ValidateExpressionResponse(
            boolean valid,
            String readableForm,
            String error
    ) {}
}
