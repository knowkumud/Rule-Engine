package com.ruleengine.api.controller;

import com.ruleengine.api.dto.RuleDtos.*;
import com.ruleengine.core.engine.ConflictDetector;
import com.ruleengine.core.engine.RuleEngine;
import com.ruleengine.core.model.*;
import com.ruleengine.core.pattern.interpreter.ExpressionParser;
import com.ruleengine.core.rule.Rule;
import com.ruleengine.metrics.collector.EvaluationMetricsCollector;
import com.ruleengine.store.entity.RuleEntity;
import com.ruleengine.store.service.RuleStoreService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/rules")
@Tag(name = "Rule Engine", description = "CRUD, evaluation, and management of classification rules")
public class RuleController {

    private static final Logger log = LoggerFactory.getLogger(RuleController.class);

    private final RuleStoreService storeService;
    private final EvaluationMetricsCollector metricsCollector;

    public RuleController(RuleStoreService storeService,
                           EvaluationMetricsCollector metricsCollector) {
        this.storeService = storeService;
        this.metricsCollector = metricsCollector;
    }

    // ========== CRUD ==========

    @PostMapping
    @Operation(summary = "Create a new rule")
    public ResponseEntity<RuleResponse> createRule(@Valid @RequestBody CreateRuleRequest request) {
        RuleEntity created = storeService.createRule(
                request.id(), request.name(), request.expression(),
                request.action(), request.priority(), "api-user" // TODO: extract from auth
        );
        return ResponseEntity.status(HttpStatus.CREATED).body(toResponse(created));
    }

    @PutMapping("/{ruleId}")
    @Operation(summary = "Update a rule (creates new version)")
    public ResponseEntity<RuleResponse> updateRule(@PathVariable String ruleId,
                                                    @Valid @RequestBody UpdateRuleRequest request) {
        RuleEntity updated = storeService.updateRule(
                ruleId, request.name(), request.expression(),
                request.action(), request.priority(), "api-user"
        );
        return ResponseEntity.ok(toResponse(updated));
    }

    @GetMapping("/{ruleId}")
    @Operation(summary = "Get current version of a rule")
    public ResponseEntity<RuleResponse> getRule(@PathVariable String ruleId) {
        return storeService.getCurrentVersion(ruleId)
                .map(r -> ResponseEntity.ok(toResponse(r)))
                .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping
    @Operation(summary = "List all current rules")
    public ResponseEntity<List<RuleResponse>> listRules() {
        List<RuleResponse> rules = storeService.loadActiveRules().stream()
                .map(this::toResponseFromRule)
                .toList();
        return ResponseEntity.ok(rules);
    }

    @PatchMapping("/{ruleId}/toggle")
    @Operation(summary = "Toggle rule active/inactive")
    public ResponseEntity<RuleResponse> toggleRule(@PathVariable String ruleId) {
        RuleEntity toggled = storeService.toggleActive(ruleId);
        return ResponseEntity.ok(toResponse(toggled));
    }

    // ========== VERSIONING ==========

    @GetMapping("/{ruleId}/versions")
    @Operation(summary = "Get version history for a rule")
    public ResponseEntity<List<RuleResponse>> getVersionHistory(@PathVariable String ruleId) {
        List<RuleResponse> history = storeService.getVersionHistory(ruleId).stream()
                .map(this::toResponse)
                .toList();
        return ResponseEntity.ok(history);
    }

    @PostMapping("/{ruleId}/rollback")
    @Operation(summary = "Rollback a rule to a previous version")
    public ResponseEntity<RuleResponse> rollback(@PathVariable String ruleId,
                                                  @Valid @RequestBody RollbackRequest request) {
        RuleEntity rolledBack = storeService.rollback(ruleId, request.targetVersion(), "api-user");
        return ResponseEntity.ok(toResponse(rolledBack));
    }

    // ========== EVALUATION ==========

    @PostMapping("/evaluate")
    @Operation(summary = "Evaluate a ticket against all active rules")
    public ResponseEntity<EvaluateResponse> evaluate(@Valid @RequestBody EvaluateRequest request) {
        Ticket ticket = Ticket.builder()
                .id(request.ticketId())
                .category(request.category())
                .subcategory(request.subcategory())
                .priority(Ticket.Priority.valueOf(request.priority().toUpperCase()))
                .source(request.source())
                .description(request.description())
                .customFields(request.customFields() != null ? request.customFields() : Map.of())
                .build();

        // Build engine with current rules
        List<Rule<Ticket>> activeRules = storeService.loadActiveRules();
        RuleEngine<Ticket> engine = RuleEngine.<Ticket>builder()
                .addRules(activeRules)
                .strategy(ConflictResolutionStrategy.PRIORITY_BASED)
                .defaultAction("route-to-general-queue")
                .build();

        EvaluationContext<Ticket> context = engine.evaluate(ticket, request.dryRun());
        metricsCollector.record(context);

        return ResponseEntity.ok(toEvaluateResponse(context));
    }

    // ========== CONFLICT DETECTION ==========

    @GetMapping("/conflicts")
    @Operation(summary = "Detect conflicts among current rules")
    public ResponseEntity<ConflictReport> detectConflicts() {
        List<Rule<Ticket>> rules = storeService.loadActiveRules();
        ConflictDetector<Ticket> detector = new ConflictDetector<>();
        var conflicts = detector.detect(rules);

        ConflictReport report = new ConflictReport(
                conflicts.size(),
                conflicts.stream()
                        .map(c -> new ConflictDetail(c.type().name(), c.involvedRuleIds(), c.description()))
                        .toList()
        );
        return ResponseEntity.ok(report);
    }

    // ========== EXPRESSION VALIDATION ==========

    @PostMapping("/validate")
    @Operation(summary = "Validate a rule expression without saving")
    public ResponseEntity<ValidateExpressionResponse> validateExpression(
            @Valid @RequestBody ValidateExpressionRequest request) {
        try {
            var expr = ExpressionParser.parse(request.expression());
            return ResponseEntity.ok(new ValidateExpressionResponse(
                    true, expr.toReadableString(), null));
        } catch (ExpressionParser.ExpressionParseException e) {
            return ResponseEntity.ok(new ValidateExpressionResponse(
                    false, null, e.getMessage()));
        }
    }

    // ========== Mappers ==========

    private RuleResponse toResponse(RuleEntity entity) {
        return new RuleResponse(
                entity.getExternalId(), entity.getName(), entity.getDescription(),
                entity.getExpression(), entity.getAction(), entity.getPriority(),
                entity.isActive(), entity.getVersion(), entity.getCreatedAt()
        );
    }

    private RuleResponse toResponseFromRule(Rule<Ticket> rule) {
        return new RuleResponse(
                rule.getId(), rule.getName(), rule.getDescription(),
                null, null, rule.getPriority(),
                rule.isActive(), 0, null
        );
    }

    private EvaluateResponse toEvaluateResponse(EvaluationContext<Ticket> ctx) {
        var matches = ctx.allResults().stream()
                .map(r -> new RuleMatchDetail(
                        r.ruleId(), r.ruleName(), r.isMatched(),
                        r.action(), r.priority(), r.evaluationTimeMs()))
                .toList();

        return new EvaluateResponse(
                ctx.evaluationId(),
                ctx.hasMatch(),
                ctx.hasMatch() ? ctx.winningResult().ruleId() : null,
                ctx.hasMatch() ? ctx.winningResult().ruleName() : null,
                ctx.hasMatch() ? ctx.winningResult().action() : null,
                ctx.getConflictCount(),
                ctx.strategyUsed().name(),
                ctx.dryRun(),
                ctx.totalEvaluationTimeMs(),
                matches
        );
    }
}
