package com.ruleengine.api.exception;

import com.ruleengine.core.pattern.interpreter.ExpressionParser;
import com.ruleengine.store.service.RuleStoreService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.Instant;
import java.util.Map;

/**
 * Centralized exception handling. Converts exceptions to structured
 * JSON error responses with correlation IDs for debugging.
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(RuleStoreService.RuleNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleNotFound(RuleStoreService.RuleNotFoundException e) {
        return buildResponse(HttpStatus.NOT_FOUND, "RULE_NOT_FOUND", e.getMessage());
    }

    @ExceptionHandler(ExpressionParser.ExpressionParseException.class)
    public ResponseEntity<Map<String, Object>> handleParseError(ExpressionParser.ExpressionParseException e) {
        return buildResponse(HttpStatus.BAD_REQUEST, "INVALID_EXPRESSION", e.getMessage());
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>> handleValidation(MethodArgumentNotValidException e) {
        String message = e.getBindingResult().getFieldErrors().stream()
                .map(fe -> fe.getField() + ": " + fe.getDefaultMessage())
                .reduce((a, b) -> a + "; " + b)
                .orElse("Validation failed");
        return buildResponse(HttpStatus.BAD_REQUEST, "VALIDATION_ERROR", message);
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Map<String, Object>> handleIllegalArg(IllegalArgumentException e) {
        return buildResponse(HttpStatus.BAD_REQUEST, "BAD_REQUEST", e.getMessage());
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> handleGeneric(Exception e) {
        log.error("Unhandled exception", e);
        return buildResponse(HttpStatus.INTERNAL_SERVER_ERROR, "INTERNAL_ERROR",
                "An unexpected error occurred");
    }

    private ResponseEntity<Map<String, Object>> buildResponse(HttpStatus status, String code, String message) {
        return ResponseEntity.status(status).body(Map.of(
                "status", status.value(),
                "error", code,
                "message", message,
                "timestamp", Instant.now().toString()
        ));
    }
}
