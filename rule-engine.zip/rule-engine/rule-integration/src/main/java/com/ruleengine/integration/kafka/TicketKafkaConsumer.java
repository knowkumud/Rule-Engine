package com.ruleengine.integration.kafka;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ruleengine.core.engine.RuleEngine;
import com.ruleengine.core.model.*;
import com.ruleengine.core.rule.Rule;
import com.ruleengine.metrics.collector.EvaluationMetricsCollector;
import com.ruleengine.store.service.RuleStoreService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

/**
 * Kafka consumer for async ticket evaluation.
 *
 * <p>Flow:</p>
 * <pre>
 * ITSM System → tickets.incoming (Kafka) → Consumer → Engine evaluates
 *     → tickets.routed (Kafka) → Downstream routing service
 * </pre>
 *
 * <p>This decouples the ITSM system from rule evaluation. Tickets can
 * be processed at the engine's pace, with backpressure handled by Kafka.</p>
 */
@Component
public class TicketKafkaConsumer {

    private static final Logger log = LoggerFactory.getLogger(TicketKafkaConsumer.class);

    private final RuleStoreService storeService;
    private final EvaluationMetricsCollector metricsCollector;
    private final KafkaTemplate<String, String> kafkaTemplate;
    private final ObjectMapper objectMapper;

    public TicketKafkaConsumer(RuleStoreService storeService,
                                EvaluationMetricsCollector metricsCollector,
                                KafkaTemplate<String, String> kafkaTemplate,
                                ObjectMapper objectMapper) {
        this.storeService = storeService;
        this.metricsCollector = metricsCollector;
        this.kafkaTemplate = kafkaTemplate;
        this.objectMapper = objectMapper;
    }

    @KafkaListener(topics = "tickets.incoming", groupId = "rule-engine")
    public void processTicket(String message) {
        try {
            Ticket ticket = parseTicket(message);

            List<Rule<Ticket>> rules = storeService.loadActiveRules();
            RuleEngine<Ticket> engine = RuleEngine.<Ticket>builder()
                    .addRules(rules)
                    .strategy(ConflictResolutionStrategy.PRIORITY_BASED)
                    .defaultAction("route-to-general-queue")
                    .build();

            EvaluationContext<Ticket> result = engine.evaluate(ticket);
            metricsCollector.record(result);

            // Publish routing decision to downstream
            if (result.hasMatch()) {
                String routingEvent = objectMapper.writeValueAsString(Map.of(
                        "ticketId", ticket.getId(),
                        "action", result.winningResult().action(),
                        "ruleId", result.winningResult().ruleId(),
                        "evaluationId", result.evaluationId()
                ));
                kafkaTemplate.send("tickets.routed", ticket.getId(), routingEvent);
                log.info("Routed ticket {} → {} (rule: {})",
                        ticket.getId(), result.winningResult().action(), result.winningResult().ruleId());
            }

        } catch (Exception e) {
            log.error("Failed to process ticket message", e);
            // TODO: send to dead letter queue
        }
    }

    private Ticket parseTicket(String json) throws Exception {
        var node = objectMapper.readTree(json);
        return Ticket.builder()
                .id(node.path("id").asText())
                .category(node.path("category").asText())
                .subcategory(node.path("subcategory").asText())
                .priority(Ticket.Priority.valueOf(node.path("priority").asText().toUpperCase()))
                .source(node.path("source").asText())
                .description(node.path("description").asText())
                .build();
    }
}
