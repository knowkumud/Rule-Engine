package com.ruleengine.integration.webhook;

import com.ruleengine.core.engine.RuleEngine;
import com.ruleengine.core.model.*;
import com.ruleengine.core.rule.Rule;
import com.ruleengine.metrics.collector.EvaluationMetricsCollector;
import com.ruleengine.store.service.RuleStoreService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * Webhook endpoint for ITSM systems that push ticket events via HTTP.
 *
 * <p>ServiceNow, Jira Service Management, etc. can call this endpoint
 * when a new ticket is created. The engine evaluates and returns the
 * routing decision synchronously.</p>
 */
@RestController
@RequestMapping("/api/v1/webhook")
public class WebhookController {

    private static final Logger log = LoggerFactory.getLogger(WebhookController.class);

    private final RuleStoreService storeService;
    private final EvaluationMetricsCollector metricsCollector;

    public WebhookController(RuleStoreService storeService,
                              EvaluationMetricsCollector metricsCollector) {
        this.storeService = storeService;
        this.metricsCollector = metricsCollector;
    }

    /**
     * Receive a ticket creation event and return routing decision.
     *
     * <p>Example ServiceNow Business Rule:</p>
     * <pre>
     * var request = new sn_ws.RESTMessageV2();
     * request.setEndpoint('https://rule-engine.internal/api/v1/webhook/ticket');
     * request.setHttpMethod('POST');
     * request.setRequestBody(JSON.stringify({
     *     id: current.number,
     *     category: current.category,
     *     priority: current.priority
     * }));
     * </pre>
     */
    @PostMapping("/ticket")
    public ResponseEntity<Map<String, Object>> handleTicketWebhook(@RequestBody Map<String, String> payload) {
        log.info("Webhook received for ticket: {}", payload.get("id"));

        try {
            Ticket ticket = Ticket.builder()
                    .id(payload.getOrDefault("id", "unknown"))
                    .category(payload.get("category"))
                    .subcategory(payload.get("subcategory"))
                    .priority(Ticket.Priority.valueOf(
                            payload.getOrDefault("priority", "MEDIUM").toUpperCase()))
                    .source(payload.getOrDefault("source", "webhook"))
                    .description(payload.get("description"))
                    .build();

            List<Rule<Ticket>> rules = storeService.loadActiveRules();
            RuleEngine<Ticket> engine = RuleEngine.<Ticket>builder()
                    .addRules(rules)
                    .strategy(ConflictResolutionStrategy.PRIORITY_BASED)
                    .defaultAction("route-to-general-queue")
                    .build();

            EvaluationContext<Ticket> result = engine.evaluate(ticket);
            metricsCollector.record(result);

            if (result.hasMatch()) {
                return ResponseEntity.ok(Map.of(
                        "ticketId", ticket.getId(),
                        "action", result.winningResult().action(),
                        "ruleId", result.winningResult().ruleId(),
                        "evaluationId", result.evaluationId(),
                        "evaluationTimeMs", result.totalEvaluationTimeMs()
                ));
            }

            return ResponseEntity.ok(Map.of(
                    "ticketId", ticket.getId(),
                    "action", "route-to-general-queue",
                    "reason", "no_matching_rules"
            ));

        } catch (Exception e) {
            log.error("Webhook processing failed for ticket: {}", payload.get("id"), e);
            return ResponseEntity.internalServerError().body(Map.of(
                    "error", "processing_failed",
                    "message", e.getMessage()
            ));
        }
    }
}
