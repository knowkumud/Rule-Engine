package com.ruleengine.core.pattern.interpreter;

import com.ruleengine.core.model.Ticket;

import java.util.Objects;

/**
 * Leaf node in the expression tree. Compares a single ticket field
 * against an expected value using the specified operator.
 *
 * <p>Example: {@code category == "network"} becomes
 * {@code new ComparisonExpression("category", Operator.EQUALS, "network")}</p>
 */
public record ComparisonExpression(
        String fieldName,
        Operator operator,
        String expectedValue
) implements Expression {

    public ComparisonExpression {
        Objects.requireNonNull(fieldName, "fieldName cannot be null");
        Objects.requireNonNull(operator, "operator cannot be null");
        Objects.requireNonNull(expectedValue, "expectedValue cannot be null");
    }

    public enum Operator {
        EQUALS("==") {
            @Override
            public boolean apply(String actual, String expected) {
                return expected.equalsIgnoreCase(actual);
            }
        },
        NOT_EQUALS("!=") {
            @Override
            public boolean apply(String actual, String expected) {
                return !expected.equalsIgnoreCase(actual);
            }
        },
        CONTAINS("contains") {
            @Override
            public boolean apply(String actual, String expected) {
                return actual != null && actual.toLowerCase().contains(expected.toLowerCase());
            }
        },
        STARTS_WITH("startsWith") {
            @Override
            public boolean apply(String actual, String expected) {
                return actual != null && actual.toLowerCase().startsWith(expected.toLowerCase());
            }
        },
        IN("in") {
            @Override
            public boolean apply(String actual, String expected) {
                // expected is comma-separated: "network,security,infrastructure"
                if (actual == null) return false;
                String[] values = expected.split(",");
                for (String v : values) {
                    if (v.trim().equalsIgnoreCase(actual)) return true;
                }
                return false;
            }
        };

        private final String symbol;

        Operator(String symbol) { this.symbol = symbol; }

        public String getSymbol() { return symbol; }

        /**
         * Each operator defines its own comparison logic.
         * This avoids a switch/if-else chain — Strategy pattern via enum.
         */
        public abstract boolean apply(String actual, String expected);

        /**
         * Parse operator from string symbol. Used by expression parser.
         */
        public static Operator fromSymbol(String symbol) {
            for (Operator op : values()) {
                if (op.symbol.equalsIgnoreCase(symbol)) return op;
            }
            throw new IllegalArgumentException("Unknown operator: " + symbol);
        }
    }

    @Override
    public boolean evaluate(Ticket ticket) {
        String actualValue = ticket.getFieldValue(fieldName);
        return operator.apply(actualValue, expectedValue);
    }

    @Override
    public String toReadableString() {
        return "%s %s '%s'".formatted(fieldName, operator.getSymbol(), expectedValue);
    }
}
