package com.ruleengine.core.model;

import java.time.Instant;
import java.util.Map;
import java.util.Collections;

/**
 * ITSM ticket domain object. Immutable — once created, a ticket's state
 * at evaluation time is frozen. Mutations create new instances via the builder.
 *
 * <p>This is the default entity type for the engine, but the engine's generic
 * design means it works on any type that implements the field accessor pattern.</p>
 */
public final class Ticket {

    private final String id;
    private final String category;
    private final String subcategory;
    private final Priority priority;
    private final String source;       // email, portal, phone, chat
    private final String description;
    private final String assignmentGroup;
    private final String requestedBy;
    private final Map<String, String> customFields;
    private final Instant createdAt;

    private Ticket(Builder builder) {
        this.id = builder.id;
        this.category = builder.category;
        this.subcategory = builder.subcategory;
        this.priority = builder.priority;
        this.source = builder.source;
        this.description = builder.description;
        this.assignmentGroup = builder.assignmentGroup;
        this.requestedBy = builder.requestedBy;
        this.customFields = builder.customFields == null
                ? Collections.emptyMap()
                : Collections.unmodifiableMap(builder.customFields);
        this.createdAt = builder.createdAt == null ? Instant.now() : builder.createdAt;
    }

    // --- Accessors (no setters — immutable) ---

    public String getId() { return id; }
    public String getCategory() { return category; }
    public String getSubcategory() { return subcategory; }
    public Priority getPriority() { return priority; }
    public String getSource() { return source; }
    public String getDescription() { return description; }
    public String getAssignmentGroup() { return assignmentGroup; }
    public String getRequestedBy() { return requestedBy; }
    public Map<String, String> getCustomFields() { return customFields; }
    public Instant getCreatedAt() { return createdAt; }

    /**
     * Returns value of a field by name. Used by the Interpreter pattern
     * so rule expressions can reference fields dynamically.
     *
     * @param fieldName the field to look up
     * @return field value as String, or custom field value, or null
     */
    public String getFieldValue(String fieldName) {
        return switch (fieldName.toLowerCase()) {
            case "category" -> category;
            case "subcategory" -> subcategory;
            case "priority" -> priority != null ? priority.name() : null;
            case "source" -> source;
            case "description" -> description;
            case "assignmentgroup", "assignment_group" -> assignmentGroup;
            case "requestedby", "requested_by" -> requestedBy;
            default -> customFields.get(fieldName);
        };
    }

    @Override
    public String toString() {
        return "Ticket{id='%s', category='%s', priority=%s, source='%s'}"
                .formatted(id, category, priority, source);
    }

    // --- Builder pattern for fluent construction ---

    public static Builder builder() {
        return new Builder();
    }

    /**
     * Returns a new builder pre-populated with this ticket's values.
     * Useful for creating modified copies without mutating the original.
     */
    public Builder toBuilder() {
        return new Builder()
                .id(id).category(category).subcategory(subcategory)
                .priority(priority).source(source).description(description)
                .assignmentGroup(assignmentGroup).requestedBy(requestedBy)
                .customFields(customFields).createdAt(createdAt);
    }

    public static final class Builder {
        private String id;
        private String category;
        private String subcategory;
        private Priority priority;
        private String source;
        private String description;
        private String assignmentGroup;
        private String requestedBy;
        private Map<String, String> customFields;
        private Instant createdAt;

        private Builder() {}

        public Builder id(String id) { this.id = id; return this; }
        public Builder category(String category) { this.category = category; return this; }
        public Builder subcategory(String subcategory) { this.subcategory = subcategory; return this; }
        public Builder priority(Priority priority) { this.priority = priority; return this; }
        public Builder source(String source) { this.source = source; return this; }
        public Builder description(String description) { this.description = description; return this; }
        public Builder assignmentGroup(String group) { this.assignmentGroup = group; return this; }
        public Builder requestedBy(String user) { this.requestedBy = user; return this; }
        public Builder customFields(Map<String, String> fields) { this.customFields = fields; return this; }
        public Builder createdAt(Instant createdAt) { this.createdAt = createdAt; return this; }

        public Ticket build() {
            if (id == null || id.isBlank()) {
                throw new IllegalStateException("Ticket ID is required");
            }
            return new Ticket(this);
        }
    }

    public enum Priority {
        CRITICAL(1), HIGH(2), MEDIUM(3), LOW(4);

        private final int level;

        Priority(int level) { this.level = level; }

        public int getLevel() { return level; }
    }
}
