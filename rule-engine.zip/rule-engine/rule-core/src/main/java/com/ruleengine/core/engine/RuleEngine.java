package com.ruleengine.core.engine;

import com.ruleengine.core.model.ConflictResolutionStrategy;
import com.ruleengine.core.model.EvaluationContext;
import com.ruleengine.core.model.RuleResult;
import com.ruleengine.core.rule.Rule;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;

/**
 * Core rule evaluation engine. Generic over entity type T.
 *
 * <p>Production features:</p>
 * <ul>
 *   <li><b>Parallel evaluation</b> — rules evaluated concurrently via CompletableFuture</li>
 *   <li><b>Conflict resolution</b> — pluggable strategy when multiple rules match</li>
 *   <li><b>Dry-run mode</b> — evaluate without side effects, for testing new rules</li>
 *   <li><b>Circuit breaker</b> — fallback when evaluation fails</li>
 *   <li><b>Timeout protection</b> — prevents runaway rule evaluation</li>
 * </ul>
 *
 * <p>This class is thread-safe. Multiple threads can call {@code evaluate()}
 * concurrently — the engine holds no mutable state between evaluations.</p>
 *
 * @param <T> the entity type to evaluate rules against
 */
public class RuleEngine<T> {

    private static final Logger log = LoggerFactory.getLogger(RuleEngine.class);

    private final List<Rule<T>> rules;
    private final ConflictResolutionStrategy strategy;
    private final ExecutorService executor;
    private final long timeoutMs;
    private final String defaultAction;

    private RuleEngine(Builder<T> builder) {
        this.rules = Collections.unmodifiableList(new ArrayList<>(builder.rules));
        this.strategy = builder.strategy;
        this.executor = builder.executor;
        this.timeoutMs = builder.timeoutMs;
        this.defaultAction = builder.defaultAction;
    }

    /**
     * Evaluate all active rules against the entity.
     * Returns full evaluation context including all results and winning match.
     *
     * @param entity the entity to evaluate
     * @return evaluation context with winning result and all intermediate results
     */
    public EvaluationContext<T> evaluate(T entity) {
        return evaluate(entity, false);
    }

    /**
     * Evaluate in dry-run mode. Same logic but flagged so downstream
     * consumers (webhooks, Kafka publishers) can skip side effects.
     *
     * @param entity  the entity to evaluate
     * @param dryRun  if true, no side effects should be triggered
     * @return evaluation context flagged as dry-run
     */
    public EvaluationContext<T> evaluate(T entity, boolean dryRun) {
        String evaluationId = UUID.randomUUID().toString();
        long startTime = System.nanoTime();

        log.debug("Starting evaluation {} for entity: {} (dryRun={})", evaluationId, entity, dryRun);

        List<Rule<T>> activeRules = rules.stream()
                .filter(Rule::isActive)
                .toList();

        if (activeRules.isEmpty()) {
            log.warn("No active rules found for evaluation {}", evaluationId);
            return buildContext(evaluationId, entity, List.of(), dryRun, startTime);
        }

        // Evaluate rules in parallel using CompletableFuture
        List<RuleResult<T>> results = evaluateParallel(activeRules, entity, evaluationId);

        return buildContext(evaluationId, entity, results, dryRun, startTime);
    }

    /**
     * Parallel rule evaluation with timeout protection.
     * Each rule gets its own CompletableFuture. If any rule times out
     * or throws, it's treated as a non-match (fail-open).
     */
    private List<RuleResult<T>> evaluateParallel(List<Rule<T>> activeRules, T entity,
                                                  String evaluationId) {
        List<CompletableFuture<RuleResult<T>>> futures = activeRules.stream()
                .map(rule -> CompletableFuture.supplyAsync(
                        () -> evaluateSafe(rule, entity, evaluationId), executor))
                .toList();

        try {
            // Wait for all with timeout
            CompletableFuture.allOf(futures.toArray(new CompletableFuture[0]))
                    .get(timeoutMs, TimeUnit.MILLISECONDS);
        } catch (TimeoutException e) {
            log.error("Evaluation {} timed out after {}ms", evaluationId, timeoutMs);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            log.error("Evaluation {} interrupted", evaluationId);
        } catch (ExecutionException e) {
            log.error("Evaluation {} failed", evaluationId, e);
        }

        // Collect completed results; skip any that didn't finish
        return futures.stream()
                .filter(f -> f.isDone() && !f.isCompletedExceptionally())
                .map(f -> {
                    try {
                        return f.get();
                    } catch (Exception e) {
                        return null;
                    }
                })
                .filter(Objects::nonNull)
                .toList();
    }

    /**
     * Safe evaluation wrapper. Catches exceptions from individual rules
     * so one bad rule doesn't crash the entire evaluation.
     */
    private RuleResult<T> evaluateSafe(Rule<T> rule, T entity, String evaluationId) {
        try {
            RuleResult<T> result = rule.evaluate(entity);
            log.trace("Evaluation {}: rule '{}' → {}",
                    evaluationId, rule.getId(), result.isMatched() ? "MATCH" : "NO_MATCH");
            return result;
        } catch (Exception e) {
            log.error("Evaluation {}: rule '{}' threw exception", evaluationId, rule.getId(), e);
            return RuleResult.noMatch(rule.getId(), rule.getName(), entity, 0);
        }
    }

    /**
     * Build the evaluation context, resolving conflicts if multiple rules matched.
     */
    private EvaluationContext<T> buildContext(String evaluationId, T entity,
                                              List<RuleResult<T>> allResults,
                                              boolean dryRun, long startNanos) {
        List<RuleResult<T>> matches = allResults.stream()
                .filter(RuleResult::isMatched)
                .toList();

        RuleResult<T> winner = resolveConflicts(matches, entity);

        long totalMs = (System.nanoTime() - startNanos) / 1_000_000;

        if (matches.size() > 1) {
            log.info("Evaluation {}: {} rules matched, resolved with {} → winner: {}",
                    evaluationId, matches.size(), strategy,
                    winner != null ? winner.ruleId() : "none");
        }

        return new EvaluationContext<>(
                evaluationId, entity, allResults, winner,
                strategy, dryRun, java.time.Instant.now(), totalMs
        );
    }

    /**
     * CONFLICT RESOLUTION — the core production concern.
     *
     * <p>When multiple rules match, which one wins? This is where
     * the Strategy pattern meets real-world requirements:</p>
     */
    private RuleResult<T> resolveConflicts(List<RuleResult<T>> matches, T entity) {
        if (matches.isEmpty()) {
            // No match — return default action as fallback (circuit breaker)
            if (defaultAction != null) {
                log.debug("No rules matched. Using default action: {}", defaultAction);
                return RuleResult.match("DEFAULT", "Default Fallback", entity,
                        defaultAction, Integer.MAX_VALUE, Map.of("reason", "no_match_fallback"), 0);
            }
            return null;
        }

        if (matches.size() == 1) {
            return matches.getFirst(); // Java 21 — replaces get(0)
        }

        // Multiple matches — resolve based on strategy
        return switch (strategy) {
            case PRIORITY_BASED -> matches.stream()
                    .min(Comparator.comparingInt(RuleResult::priority))
                    .orElse(null);

            case FIRST_MATCH -> matches.getFirst();

            case WEIGHTED_SCORE -> {
                // Group by action, sum priorities (lower = better, so we invert)
                Map<String, Integer> scores = matches.stream()
                        .collect(Collectors.groupingBy(
                                RuleResult::action,
                                Collectors.summingInt(r -> 1000 - r.priority())));
                String bestAction = scores.entrySet().stream()
                        .max(Map.Entry.comparingByValue())
                        .map(Map.Entry::getKey)
                        .orElse(null);
                yield matches.stream()
                        .filter(r -> r.action().equals(bestAction))
                        .findFirst()
                        .orElse(null);
            }

            case ALL_MATCHING -> matches.getFirst(); // caller should use allResults
        };
    }

    /**
     * Returns an unmodifiable view of the registered rules.
     * Useful for admin UI listing and conflict detection.
     */
    public List<Rule<T>> getRules() {
        return rules;
    }

    public ConflictResolutionStrategy getStrategy() {
        return strategy;
    }

    // --- BUILDER ---

    public static <T> Builder<T> builder() {
        return new Builder<>();
    }

    public static final class Builder<T> {
        private final List<Rule<T>> rules = new ArrayList<>();
        private ConflictResolutionStrategy strategy = ConflictResolutionStrategy.PRIORITY_BASED;
        private ExecutorService executor;
        private long timeoutMs = 5_000; // 5 second default
        private String defaultAction;

        private Builder() {}

        public Builder<T> addRule(Rule<T> rule) {
            this.rules.add(rule);
            return this;
        }

        public Builder<T> addRules(Collection<Rule<T>> rules) {
            this.rules.addAll(rules);
            return this;
        }

        public Builder<T> strategy(ConflictResolutionStrategy strategy) {
            this.strategy = strategy;
            return this;
        }

        /**
         * Custom executor for rule evaluation threads.
         * If not set, creates a cached thread pool.
         */
        public Builder<T> executor(ExecutorService executor) {
            this.executor = executor;
            return this;
        }

        /**
         * Timeout for the entire evaluation. If rules don't complete
         * within this window, partial results are returned.
         */
        public Builder<T> timeoutMs(long timeoutMs) {
            this.timeoutMs = timeoutMs;
            return this;
        }

        /**
         * Default action when no rules match. Acts as a circuit breaker
         * so tickets don't get lost — they route to a fallback queue.
         */
        public Builder<T> defaultAction(String defaultAction) {
            this.defaultAction = defaultAction;
            return this;
        }

        public RuleEngine<T> build() {
            if (executor == null) {
                executor = Executors.newCachedThreadPool(r -> {
                    Thread t = new Thread(r, "rule-engine-eval");
                    t.setDaemon(true); // don't prevent JVM shutdown
                    return t;
                });
            }
            return new RuleEngine<>(this);
        }
    }
}
