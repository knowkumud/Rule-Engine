package com.ruleengine.core.model;

import java.time.Instant;
import java.util.List;
import java.util.Collections;

/**
 * Immutable snapshot of an entire evaluation run.
 * Contains all results (matches and misses), timing, and the resolution strategy used.
 *
 * <p>This is what gets persisted for audit and what metrics are derived from.</p>
 *
 * @param <T> the entity type evaluated
 */
public record EvaluationContext<T>(
        String evaluationId,
        T entity,
        List<RuleResult<T>> allResults,
        RuleResult<T> winningResult,
        ConflictResolutionStrategy strategyUsed,
        boolean dryRun,
        Instant startedAt,
        long totalEvaluationTimeMs
) {

    public EvaluationContext {
        allResults = allResults == null
                ? Collections.emptyList()
                : Collections.unmodifiableList(allResults);
    }

    public boolean hasMatch() {
        return winningResult != null && winningResult.isMatched();
    }

    public List<RuleResult<T>> getMatchedResults() {
        return allResults.stream()
                .filter(RuleResult::isMatched)
                .toList(); // Java 16+ immutable list
    }

    public int getConflictCount() {
        return Math.max(0, getMatchedResults().size() - 1);
    }
}
