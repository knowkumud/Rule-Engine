package com.ruleengine.core.pattern.interpreter;

import com.ruleengine.core.model.RuleResult;
import com.ruleengine.core.model.Ticket;
import com.ruleengine.core.rule.Rule;

import java.util.Map;
import java.util.Objects;

/**
 * Adapts an {@link Expression} (from the interpreter pattern) into a
 * {@link Rule} (the engine's evaluation unit).
 *
 * <p>This is the glue between the parsing layer and the evaluation engine.
 * Business users write expression strings → parser creates Expression tree →
 * ExpressionRule wraps it so the engine can evaluate it uniformly.</p>
 */
public class ExpressionRule implements Rule<Ticket> {

    private final String id;
    private final String name;
    private final String description;
    private final int priority;
    private final String action;
    private final Expression expression;
    private final boolean active;

    private ExpressionRule(Builder builder) {
        this.id = Objects.requireNonNull(builder.id, "Rule ID is required");
        this.name = Objects.requireNonNull(builder.name, "Rule name is required");
        this.description = builder.description != null ? builder.description : "";
        this.priority = builder.priority;
        this.action = Objects.requireNonNull(builder.action, "Action is required");
        this.expression = Objects.requireNonNull(builder.expression, "Expression is required");
        this.active = builder.active;
    }

    @Override
    public String getId() { return id; }

    @Override
    public String getName() { return name; }

    @Override
    public int getPriority() { return priority; }

    @Override
    public String getDescription() { return description; }

    @Override
    public boolean isActive() { return active; }

    public String getAction() { return action; }
    public Expression getExpression() { return expression; }

    @Override
    public RuleResult<Ticket> evaluate(Ticket ticket) {
        long start = System.nanoTime();
        boolean matched = expression.evaluate(ticket);
        long evalTimeMs = (System.nanoTime() - start) / 1_000_000;

        if (matched) {
            return RuleResult.match(id, name, ticket, action, priority,
                    Map.of("expression", expression.toReadableString()), evalTimeMs);
        }
        return RuleResult.noMatch(id, name, ticket, evalTimeMs);
    }

    @Override
    public String toString() {
        return "ExpressionRule{id='%s', expr=%s, action='%s', priority=%d}"
                .formatted(id, expression.toReadableString(), action, priority);
    }

    // --- BUILDER PATTERN: Fluent rule construction ---

    /**
     * Fluent builder for constructing rules. Two modes:
     * <pre>
     * // From expression string (business user input)
     * ExpressionRule.builder()
     *     .id("R001")
     *     .name("High-priority network tickets")
     *     .expressionString("category == 'network' AND priority == 'HIGH'")
     *     .action("route-to-netops")
     *     .priority(1)
     *     .build();
     *
     * // From pre-built Expression object (programmatic)
     * ExpressionRule.builder()
     *     .id("R002")
     *     .name("Monitoring alerts")
     *     .expression(new ComparisonExpression("source", EQUALS, "monitoring"))
     *     .action("route-to-sre")
     *     .priority(2)
     *     .build();
     * </pre>
     */
    public static Builder builder() {
        return new Builder();
    }

    public static final class Builder {
        private String id;
        private String name;
        private String description;
        private int priority = 100; // default: low priority
        private String action;
        private Expression expression;
        private boolean active = true;

        private Builder() {}

        public Builder id(String id) { this.id = id; return this; }
        public Builder name(String name) { this.name = name; return this; }
        public Builder description(String desc) { this.description = desc; return this; }
        public Builder priority(int priority) { this.priority = priority; return this; }
        public Builder action(String action) { this.action = action; return this; }
        public Builder active(boolean active) { this.active = active; return this; }

        /**
         * Set expression from a pre-built Expression object.
         */
        public Builder expression(Expression expression) {
            this.expression = expression;
            return this;
        }

        /**
         * Parse an expression string and set as this rule's expression.
         * This is the typical path for rules created via admin UI.
         */
        public Builder expressionString(String expressionStr) {
            this.expression = ExpressionParser.parse(expressionStr);
            return this;
        }

        public ExpressionRule build() {
            return new ExpressionRule(this);
        }
    }
}
