package com.ruleengine.core.pattern.interpreter;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Recursive descent parser that converts rule expression strings into
 * an executable {@link Expression} AST.
 *
 * <p>Supported syntax:</p>
 * <pre>
 *   "category == 'network'"
 *   "category == 'network' AND priority == 'HIGH'"
 *   "category == 'network' AND (priority == 'HIGH' OR source == 'monitoring')"
 *   "NOT category == 'hr'"
 * </pre>
 *
 * <p>This is the bridge between what business users type in the admin UI
 * and what the engine actually executes.</p>
 */
public final class ExpressionParser {

    // Tokenizes: words, operators (==, !=), quoted strings, parentheses
    private static final Pattern TOKEN_PATTERN = Pattern.compile(
            "'[^']*'|\"[^\"]*\"|==|!=|\\(|\\)|\\w+"
    );

    private final List<String> tokens;
    private int pos;

    private ExpressionParser(List<String> tokens) {
        this.tokens = tokens;
        this.pos = 0;
    }

    /**
     * Parse an expression string into an executable Expression tree.
     *
     * @param input the rule expression (e.g., "category == 'network' AND priority == 'HIGH'")
     * @return parsed Expression that can evaluate against any Ticket
     * @throws ExpressionParseException if the expression is malformed
     */
    public static Expression parse(String input) {
        if (input == null || input.isBlank()) {
            throw new ExpressionParseException("Expression cannot be null or blank");
        }

        List<String> tokens = tokenize(input);
        if (tokens.isEmpty()) {
            throw new ExpressionParseException("No valid tokens found in: " + input);
        }

        ExpressionParser parser = new ExpressionParser(tokens);
        Expression result = parser.parseExpression();

        if (parser.pos < parser.tokens.size()) {
            throw new ExpressionParseException(
                    "Unexpected token at position %d: '%s'".formatted(
                            parser.pos, parser.tokens.get(parser.pos)));
        }

        return result;
    }

    private static List<String> tokenize(String input) {
        List<String> tokens = new ArrayList<>();
        Matcher matcher = TOKEN_PATTERN.matcher(input);
        while (matcher.find()) {
            tokens.add(matcher.group());
        }
        return tokens;
    }

    /**
     * expression ::= andExpr (OR andExpr)*
     * OR has lower precedence than AND.
     */
    private Expression parseExpression() {
        Expression left = parseAndExpression();

        while (hasNext() && peekIs("OR")) {
            consume("OR");
            Expression right = parseAndExpression();
            left = new OrExpression(left, right);
        }

        return left;
    }

    /**
     * andExpr ::= unaryExpr (AND unaryExpr)*
     */
    private Expression parseAndExpression() {
        Expression left = parseUnary();

        while (hasNext() && peekIs("AND")) {
            consume("AND");
            Expression right = parseUnary();
            left = new AndExpression(left, right);
        }

        return left;
    }

    /**
     * unaryExpr ::= NOT unaryExpr | primary
     */
    private Expression parseUnary() {
        if (hasNext() && peekIs("NOT")) {
            consume("NOT");
            Expression inner = parseUnary();
            return new NotExpression(inner);
        }
        return parsePrimary();
    }

    /**
     * primary ::= '(' expression ')' | comparison
     * comparison ::= fieldName operator value
     */
    private Expression parsePrimary() {
        if (hasNext() && peekIs("(")) {
            consume("(");
            Expression expr = parseExpression();
            consume(")");
            return expr;
        }

        return parseComparison();
    }

    private Expression parseComparison() {
        String fieldName = advance("field name");
        String operatorStr = advance("operator");
        String rawValue = advance("value");

        // Strip quotes from value
        String value = stripQuotes(rawValue);

        ComparisonExpression.Operator operator;
        try {
            operator = ComparisonExpression.Operator.fromSymbol(operatorStr);
        } catch (IllegalArgumentException e) {
            throw new ExpressionParseException("Unknown operator '%s'. Supported: ==, !=, contains, startsWith, in"
                    .formatted(operatorStr));
        }

        return new ComparisonExpression(fieldName, operator, value);
    }

    // --- Token navigation helpers ---

    private boolean hasNext() {
        return pos < tokens.size();
    }

    private boolean peekIs(String expected) {
        return hasNext() && tokens.get(pos).equalsIgnoreCase(expected);
    }

    private void consume(String expected) {
        if (!hasNext()) {
            throw new ExpressionParseException("Expected '%s' but reached end of expression".formatted(expected));
        }
        String actual = tokens.get(pos);
        if (!actual.equalsIgnoreCase(expected)) {
            throw new ExpressionParseException("Expected '%s' but found '%s' at position %d"
                    .formatted(expected, actual, pos));
        }
        pos++;
    }

    private String advance(String description) {
        if (!hasNext()) {
            throw new ExpressionParseException("Expected %s but reached end of expression".formatted(description));
        }
        return tokens.get(pos++);
    }

    private static String stripQuotes(String value) {
        if (value.length() >= 2 &&
                ((value.startsWith("'") && value.endsWith("'")) ||
                 (value.startsWith("\"") && value.endsWith("\"")))) {
            return value.substring(1, value.length() - 1);
        }
        return value;
    }

    /**
     * Checked exception for parse failures. Provides clear error messages
     * that can be surfaced to business users in the admin UI.
     */
    public static class ExpressionParseException extends RuntimeException {
        public ExpressionParseException(String message) {
            super(message);
        }
    }
}
