package com.ruleengine.core.pattern.composite;

import com.ruleengine.core.model.RuleResult;
import com.ruleengine.core.rule.Rule;

import java.util.*;

/**
 * COMPOSITE PATTERN: Treats a group of rules as a single rule.
 *
 * <p>This is the key pattern for building complex rule trees:</p>
 * <pre>
 *   AND(
 *     category == "network",
 *     OR(
 *       priority == CRITICAL,
 *       source == "monitoring"
 *     )
 *   ) → route to NetworkOps
 * </pre>
 *
 * <p>Each CompositeRule IS-A Rule<T>, so composites nest arbitrarily deep.
 * The Operator enum controls how child results combine (AND vs OR).</p>
 *
 * @param <T> entity type
 */
public class CompositeRule<T> implements Rule<T> {

    private final String id;
    private final String name;
    private final int priority;
    private final String action;
    private final Operator operator;
    private final List<Rule<T>> children;

    public enum Operator {
        /** All children must match */
        AND,
        /** At least one child must match */
        OR
    }

    private CompositeRule(String id, String name, int priority, String action,
                          Operator operator, List<Rule<T>> children) {
        this.id = Objects.requireNonNull(id);
        this.name = Objects.requireNonNull(name);
        this.priority = priority;
        this.action = action;
        this.operator = Objects.requireNonNull(operator);
        this.children = Collections.unmodifiableList(new ArrayList<>(children));

        if (children.isEmpty()) {
            throw new IllegalArgumentException("CompositeRule must have at least one child rule");
        }
    }

    @Override
    public String getId() { return id; }

    @Override
    public String getName() { return name; }

    @Override
    public int getPriority() { return priority; }

    @Override
    public RuleResult<T> evaluate(T entity) {
        long start = System.nanoTime();

        List<RuleResult<T>> childResults = children.stream()
                .map(child -> child.evaluate(entity))
                .toList();

        boolean matched = switch (operator) {
            case AND -> childResults.stream().allMatch(RuleResult::isMatched);
            case OR -> childResults.stream().anyMatch(RuleResult::isMatched);
        };

        long evalTimeMs = (System.nanoTime() - start) / 1_000_000;

        if (matched) {
            Map<String, Object> metadata = new HashMap<>();
            metadata.put("operator", operator.name());
            metadata.put("childCount", children.size());
            metadata.put("matchedChildren", childResults.stream()
                    .filter(RuleResult::isMatched)
                    .map(RuleResult::ruleId)
                    .toList());
            return RuleResult.match(id, name, entity, action, priority, metadata, evalTimeMs);
        }

        return RuleResult.noMatch(id, name, entity, evalTimeMs);
    }

    public Operator getOperator() { return operator; }
    public List<Rule<T>> getChildren() { return children; }

    // --- Fluent static factories ---

    /**
     * Creates an AND composite: all children must match.
     * <pre>
     * CompositeRule.and("r1", "High-priority network", 1, "route-to-netops",
     *     categoryRule, priorityRule
     * );
     * </pre>
     */
    @SafeVarargs
    public static <T> CompositeRule<T> and(String id, String name, int priority,
                                            String action, Rule<T>... rules) {
        return new CompositeRule<>(id, name, priority, action, Operator.AND, List.of(rules));
    }

    /**
     * Creates an OR composite: at least one child must match.
     */
    @SafeVarargs
    public static <T> CompositeRule<T> or(String id, String name, int priority,
                                           String action, Rule<T>... rules) {
        return new CompositeRule<>(id, name, priority, action, Operator.OR, List.of(rules));
    }

    /**
     * Builder for complex composites with many children.
     */
    public static <T> CompositeBuilder<T> builder() {
        return new CompositeBuilder<>();
    }

    public static class CompositeBuilder<T> {
        private String id;
        private String name;
        private int priority;
        private String action;
        private Operator operator = Operator.AND;
        private final List<Rule<T>> children = new ArrayList<>();

        public CompositeBuilder<T> id(String id) { this.id = id; return this; }
        public CompositeBuilder<T> name(String name) { this.name = name; return this; }
        public CompositeBuilder<T> priority(int p) { this.priority = p; return this; }
        public CompositeBuilder<T> action(String action) { this.action = action; return this; }
        public CompositeBuilder<T> operator(Operator op) { this.operator = op; return this; }
        public CompositeBuilder<T> addRule(Rule<T> rule) { this.children.add(rule); return this; }
        public CompositeBuilder<T> addRules(Collection<Rule<T>> rules) { this.children.addAll(rules); return this; }

        public CompositeRule<T> build() {
            return new CompositeRule<>(id, name, priority, action, operator, children);
        }
    }
}
