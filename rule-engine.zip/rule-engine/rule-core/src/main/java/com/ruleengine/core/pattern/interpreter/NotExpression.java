package com.ruleengine.core.pattern.interpreter;

import com.ruleengine.core.model.Ticket;

/**
 * NOT expression: negates the inner expression result.
 */
public record NotExpression(Expression inner) implements Expression {
    @Override
    public boolean evaluate(Ticket ticket) {
        return !inner.evaluate(ticket);
    }

    @Override
    public String toReadableString() {
        return "(NOT %s)".formatted(inner.toReadableString());
    }
}
