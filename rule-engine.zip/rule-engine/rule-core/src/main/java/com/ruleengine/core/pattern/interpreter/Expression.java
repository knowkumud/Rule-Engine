package com.ruleengine.core.pattern.interpreter;

import com.ruleengine.core.model.Ticket;

import java.util.function.Predicate;

/**
 * INTERPRETER PATTERN: Defines a grammar for rule expressions and
 * interprets them at runtime.
 *
 * <p>Grammar:</p>
 * <pre>
 *   expression  ::= comparison | andExpr | orExpr | notExpr
 *   comparison  ::= fieldName operator value
 *   andExpr     ::= expression AND expression
 *   orExpr      ::= expression OR expression
 *   notExpr     ::= NOT expression
 *   operator    ::= '==' | '!=' | 'contains' | 'startsWith'
 * </pre>
 *
 * <p>Each node in the AST is an Expression that can evaluate itself
 * against a Ticket. This is how business users write rules as strings
 * that get parsed into executable logic.</p>
 */
public sealed interface Expression extends Predicate<Ticket>
        permits ComparisonExpression, AndExpression, OrExpression, NotExpression {

    /**
     * Evaluate this expression against a ticket.
     * Returns true if the expression matches.
     */
    boolean evaluate(Ticket ticket);

    /**
     * Bridge to Predicate — enables Stream.filter(expression), etc.
     */
    @Override
    default boolean test(Ticket ticket) {
        return evaluate(ticket);
    }

    /**
     * Human-readable representation of this expression tree.
     * Used for logging, debugging, and displaying rules in admin UI.
     */
    String toReadableString();
}
