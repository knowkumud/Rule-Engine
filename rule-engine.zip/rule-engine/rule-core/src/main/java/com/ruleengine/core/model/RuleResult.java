package com.ruleengine.core.model;

import java.time.Instant;
import java.util.Map;
import java.util.Collections;

/**
 * Immutable evaluation result. Uses Java record for:
 * - Automatic equals/hashCode/toString
 * - Immutability guarantee (no setter footguns)
 * - Compact syntax
 *
 * <p>The metadata map allows rules to attach context about WHY they matched,
 * which is critical for audit logging and debugging rule conflicts.</p>
 *
 * @param <T> the entity type that was evaluated
 */
public record RuleResult<T>(
        String ruleId,
        String ruleName,
        boolean matched,
        T entity,
        String action,
        int priority,
        Map<String, Object> metadata,
        Instant evaluatedAt,
        long evaluationTimeMs
) {

    /**
     * Canonical constructor with defensive copy on metadata.
     * Prevents external mutation of result state after creation.
     */
    public RuleResult {
        metadata = metadata == null
                ? Collections.emptyMap()
                : Collections.unmodifiableMap(metadata);
        evaluatedAt = evaluatedAt == null ? Instant.now() : evaluatedAt;
    }

    public boolean isMatched() {
        return matched;
    }

    /**
     * Factory for a successful match.
     */
    public static <T> RuleResult<T> match(String ruleId, String ruleName, T entity,
                                           String action, int priority,
                                           Map<String, Object> metadata, long evalTimeMs) {
        return new RuleResult<>(ruleId, ruleName, true, entity, action,
                priority, metadata, Instant.now(), evalTimeMs);
    }

    /**
     * Factory for a non-match. Retains rule context for metrics
     * (we track miss rates per rule too).
     */
    public static <T> RuleResult<T> noMatch(String ruleId, String ruleName,
                                             T entity, long evalTimeMs) {
        return new RuleResult<>(ruleId, ruleName, false, entity, null,
                Integer.MAX_VALUE, Map.of(), Instant.now(), evalTimeMs);
    }
}
