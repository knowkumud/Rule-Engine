package com.ruleengine.core.model;

/**
 * Strategy for resolving conflicts when multiple rules match the same entity.
 * This is a real production problem — without explicit conflict resolution,
 * rule engines produce non-deterministic results.
 *
 * <p>Each strategy represents a different business requirement:</p>
 * <ul>
 *   <li>PRIORITY_BASED — most common. Rules have priority; lowest number wins.</li>
 *   <li>FIRST_MATCH — evaluation stops at first match. Order-dependent.</li>
 *   <li>WEIGHTED_SCORE — each matching rule contributes a score. Highest aggregate wins.</li>
 *   <li>ALL_MATCHING — no conflict resolution. Returns all matches. Useful for tagging.</li>
 * </ul>
 */
public enum ConflictResolutionStrategy {

    /**
     * Select the matching rule with the lowest priority number.
     * Deterministic as long as no two rules share the same priority.
     */
    PRIORITY_BASED,

    /**
     * Return the first rule that matches. Evaluation short-circuits.
     * Fast but order-dependent — dangerous if rule ordering isn't explicit.
     */
    FIRST_MATCH,

    /**
     * Each match contributes a weight. Sum weights per action/team.
     * Useful when multiple signals should contribute to routing decision.
     */
    WEIGHTED_SCORE,

    /**
     * No conflict resolution — return every match.
     * Appropriate for tagging/labeling where multiple labels can apply.
     */
    ALL_MATCHING
}
