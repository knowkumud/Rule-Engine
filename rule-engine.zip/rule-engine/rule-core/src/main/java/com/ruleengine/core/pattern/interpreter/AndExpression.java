package com.ruleengine.core.pattern.interpreter;

import com.ruleengine.core.model.Ticket;

/**
 * AND expression: both left and right must evaluate to true.
 */
public record AndExpression(Expression left, Expression right) implements Expression {
    @Override
    public boolean evaluate(Ticket ticket) {
        return left.evaluate(ticket) && right.evaluate(ticket);
    }

    @Override
    public String toReadableString() {
        return "(%s AND %s)".formatted(left.toReadableString(), right.toReadableString());
    }
}
