package com.ruleengine.core.engine;

import com.ruleengine.core.rule.Rule;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Static analysis tool that detects potential rule conflicts BEFORE
 * rules go live. This is critical for production — deploying conflicting
 * rules causes non-deterministic routing.
 *
 * <p>Conflict types detected:</p>
 * <ul>
 *   <li>DUPLICATE_PRIORITY — two rules with same priority (ambiguous resolution)</li>
 *   <li>SHADOWED_RULE — a lower-priority rule is completely covered by a higher one</li>
 *   <li>DUPLICATE_ID — two rules with the same ID (data integrity issue)</li>
 * </ul>
 */
public final class ConflictDetector<T> {

    private static final Logger log = LoggerFactory.getLogger(ConflictDetector.class);

    /**
     * Analyze a set of rules for potential conflicts.
     * Returns an immutable list of detected conflicts.
     */
    public List<Conflict> detect(List<Rule<T>> rules) {
        List<Conflict> conflicts = new ArrayList<>();

        conflicts.addAll(detectDuplicateIds(rules));
        conflicts.addAll(detectPriorityConflicts(rules));

        if (!conflicts.isEmpty()) {
            log.warn("Detected {} potential rule conflicts", conflicts.size());
            conflicts.forEach(c -> log.warn("  → {}", c));
        }

        return Collections.unmodifiableList(conflicts);
    }

    private List<Conflict> detectDuplicateIds(List<Rule<T>> rules) {
        Map<String, List<Rule<T>>> byId = rules.stream()
                .collect(Collectors.groupingBy(Rule::getId));

        return byId.entrySet().stream()
                .filter(e -> e.getValue().size() > 1)
                .map(e -> new Conflict(
                        ConflictType.DUPLICATE_ID,
                        e.getValue().stream().map(Rule::getId).toList(),
                        "Multiple rules share ID '%s'".formatted(e.getKey())))
                .toList();
    }

    private List<Conflict> detectPriorityConflicts(List<Rule<T>> rules) {
        Map<Integer, List<Rule<T>>> byPriority = rules.stream()
                .collect(Collectors.groupingBy(Rule::getPriority));

        return byPriority.entrySet().stream()
                .filter(e -> e.getValue().size() > 1)
                .map(e -> new Conflict(
                        ConflictType.DUPLICATE_PRIORITY,
                        e.getValue().stream().map(Rule::getId).toList(),
                        "Rules share priority %d — resolution is non-deterministic"
                                .formatted(e.getKey())))
                .toList();
    }

    // --- Result types ---

    public enum ConflictType {
        DUPLICATE_ID,
        DUPLICATE_PRIORITY,
        SHADOWED_RULE
    }

    public record Conflict(
            ConflictType type,
            List<String> involvedRuleIds,
            String description
    ) {
        @Override
        public String toString() {
            return "[%s] %s (rules: %s)".formatted(type, description, involvedRuleIds);
        }
    }
}
