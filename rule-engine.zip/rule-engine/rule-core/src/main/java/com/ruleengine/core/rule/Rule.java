package com.ruleengine.core.rule;

import com.ruleengine.core.model.RuleResult;
import java.util.function.Predicate;

/**
 * Core rule abstraction. Generic over entity type T so the engine
 * works on tickets, employees, assets — any domain object.
 *
 * <p>Design choice: extends {@link Predicate} so rules compose naturally
 * with {@code and()}, {@code or()}, {@code negate()} from the JDK.
 * This is intentional — we get boolean algebra on rules for free.</p>
 *
 * @param <T> the type of entity this rule evaluates against
 */
public interface Rule<T> extends Predicate<T> {

    /**
     * Unique identifier for this rule. Used for versioning, metrics, and conflict detection.
     */
    String getId();

    /**
     * Human-readable name shown in admin UI and logs.
     */
    String getName();

    /**
     * Rule priority for conflict resolution. Lower number = higher priority.
     * When multiple rules match, the engine uses this to determine winner.
     */
    int getPriority();

    /**
     * Evaluate this rule against the given entity.
     * Returns a rich result with match status, matched rule ID, and metadata.
     *
     * @param entity the entity to evaluate
     * @return evaluation result with context
     */
    RuleResult<T> evaluate(T entity);

    /**
     * Bridge to Predicate interface — delegates to evaluate().
     * This lets rules work with Stream.filter(), CompletableFuture, etc.
     */
    @Override
    default boolean test(T entity) {
        return evaluate(entity).isMatched();
    }

    /**
     * Whether this rule is currently active. Inactive rules are skipped
     * during evaluation but retained for audit/versioning.
     */
    default boolean isActive() {
        return true;
    }

    /**
     * Optional description for business users configuring rules via UI.
     */
    default String getDescription() {
        return "";
    }
}
