package com.ruleengine.core.pattern.interpreter;

import com.ruleengine.core.model.Ticket;

/**
 * OR expression: at least one of left/right must evaluate to true.
 */
public record OrExpression(Expression left, Expression right) implements Expression {
    @Override
    public boolean evaluate(Ticket ticket) {
        return left.evaluate(ticket) || right.evaluate(ticket);
    }

    @Override
    public String toReadableString() {
        return "(%s OR %s)".formatted(left.toReadableString(), right.toReadableString());
    }
}
