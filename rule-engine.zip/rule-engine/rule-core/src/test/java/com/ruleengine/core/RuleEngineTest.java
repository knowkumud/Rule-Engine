package com.ruleengine.core;

import com.ruleengine.core.engine.ConflictDetector;
import com.ruleengine.core.engine.RuleEngine;
import com.ruleengine.core.model.*;
import com.ruleengine.core.pattern.composite.CompositeRule;
import com.ruleengine.core.pattern.interpreter.*;
import com.ruleengine.core.pattern.interpreter.ComparisonExpression.Operator;
import com.ruleengine.core.rule.Rule;
import org.junit.jupiter.api.*;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Tests for the core rule engine. No Spring context — pure Java unit tests.
 * Tests are organized by feature to demonstrate systematic testing approach.
 */
class RuleEngineTest {

    private Ticket networkHighTicket;
    private Ticket hrMediumTicket;
    private Ticket securityCriticalTicket;

    @BeforeEach
    void setUp() {
        networkHighTicket = Ticket.builder()
                .id("INC001")
                .category("network")
                .subcategory("firewall")
                .priority(Ticket.Priority.HIGH)
                .source("monitoring")
                .description("Firewall alerts spiking on prod-fw-01")
                .build();

        hrMediumTicket = Ticket.builder()
                .id("INC002")
                .category("hr")
                .subcategory("onboarding")
                .priority(Ticket.Priority.MEDIUM)
                .source("portal")
                .description("New hire needs laptop and badge access")
                .build();

        securityCriticalTicket = Ticket.builder()
                .id("INC003")
                .category("security")
                .priority(Ticket.Priority.CRITICAL)
                .source("monitoring")
                .description("Unauthorized access attempt detected")
                .build();
    }

    // ========== EXPRESSION PARSER TESTS ==========

    @Nested
    @DisplayName("Expression Parser")
    class ExpressionParserTests {

        @Test
        @DisplayName("parses simple equality expression")
        void parseSimpleEquals() {
            Expression expr = ExpressionParser.parse("category == 'network'");
            assertTrue(expr.evaluate(networkHighTicket));
            assertFalse(expr.evaluate(hrMediumTicket));
        }

        @Test
        @DisplayName("parses AND expression")
        void parseAnd() {
            Expression expr = ExpressionParser.parse(
                    "category == 'network' AND priority == 'HIGH'");
            assertTrue(expr.evaluate(networkHighTicket));
            assertFalse(expr.evaluate(hrMediumTicket));
        }

        @Test
        @DisplayName("parses OR expression")
        void parseOr() {
            Expression expr = ExpressionParser.parse(
                    "category == 'network' OR category == 'hr'");
            assertTrue(expr.evaluate(networkHighTicket));
            assertTrue(expr.evaluate(hrMediumTicket));
            assertFalse(expr.evaluate(securityCriticalTicket));
        }

        @Test
        @DisplayName("parses nested parenthesized expressions")
        void parseNested() {
            Expression expr = ExpressionParser.parse(
                    "source == 'monitoring' AND (category == 'network' OR category == 'security')");
            assertTrue(expr.evaluate(networkHighTicket));
            assertTrue(expr.evaluate(securityCriticalTicket));
            assertFalse(expr.evaluate(hrMediumTicket));
        }

        @Test
        @DisplayName("parses NOT expression")
        void parseNot() {
            Expression expr = ExpressionParser.parse("NOT category == 'hr'");
            assertTrue(expr.evaluate(networkHighTicket));
            assertFalse(expr.evaluate(hrMediumTicket));
        }

        @Test
        @DisplayName("contains operator matches substring")
        void parseContains() {
            Expression expr = ExpressionParser.parse("description contains 'firewall'");
            assertTrue(expr.evaluate(networkHighTicket));
            assertFalse(expr.evaluate(hrMediumTicket));
        }

        @Test
        @DisplayName("rejects empty expression")
        void rejectEmpty() {
            assertThrows(ExpressionParser.ExpressionParseException.class,
                    () -> ExpressionParser.parse(""));
        }

        @Test
        @DisplayName("rejects malformed expression")
        void rejectMalformed() {
            assertThrows(ExpressionParser.ExpressionParseException.class,
                    () -> ExpressionParser.parse("category =="));
        }

        @Test
        @DisplayName("generates readable string from parsed expression")
        void readableString() {
            Expression expr = ExpressionParser.parse(
                    "category == 'network' AND priority == 'HIGH'");
            String readable = expr.toReadableString();
            assertTrue(readable.contains("category"));
            assertTrue(readable.contains("AND"));
        }
    }

    // ========== COMPOSITE RULE TESTS ==========

    @Nested
    @DisplayName("Composite Rules")
    class CompositeRuleTests {

        @Test
        @DisplayName("AND composite requires all children to match")
        void andComposite() {
            Rule<Ticket> categoryRule = buildExpressionRule("R1", "category == 'network'", "netops", 1);
            Rule<Ticket> priorityRule = buildExpressionRule("R2", "priority == 'HIGH'", "netops", 2);

            CompositeRule<Ticket> andRule = CompositeRule.and(
                    "C1", "High-priority network", 1, "route-to-netops",
                    categoryRule, priorityRule);

            RuleResult<Ticket> result = andRule.evaluate(networkHighTicket);
            assertTrue(result.isMatched());
            assertEquals("route-to-netops", result.action());
        }

        @Test
        @DisplayName("OR composite requires at least one child to match")
        void orComposite() {
            Rule<Ticket> networkRule = buildExpressionRule("R1", "category == 'network'", "ops", 1);
            Rule<Ticket> securityRule = buildExpressionRule("R2", "category == 'security'", "ops", 2);

            CompositeRule<Ticket> orRule = CompositeRule.or(
                    "C2", "Ops tickets", 1, "route-to-ops",
                    networkRule, securityRule);

            assertTrue(orRule.evaluate(networkHighTicket).isMatched());
            assertTrue(orRule.evaluate(securityCriticalTicket).isMatched());
            assertFalse(orRule.evaluate(hrMediumTicket).isMatched());
        }

        @Test
        @DisplayName("metadata tracks matched children")
        void compositeMetadata() {
            Rule<Ticket> r1 = buildExpressionRule("R1", "category == 'network'", "test", 1);
            Rule<Ticket> r2 = buildExpressionRule("R2", "source == 'monitoring'", "test", 2);

            CompositeRule<Ticket> rule = CompositeRule.and(
                    "C1", "test", 1, "test-action", r1, r2);

            RuleResult<Ticket> result = rule.evaluate(networkHighTicket);
            assertTrue(result.metadata().containsKey("matchedChildren"));
        }
    }

    // ========== ENGINE EVALUATION TESTS ==========

    @Nested
    @DisplayName("Rule Engine Evaluation")
    class EngineEvaluationTests {

        @Test
        @DisplayName("evaluates and returns winning rule by priority")
        void priorityBasedResolution() {
            Rule<Ticket> lowPriority = buildExpressionRule("R1", "category == 'network'", "general-queue", 10);
            Rule<Ticket> highPriority = buildExpressionRule("R2", "source == 'monitoring'", "sre-queue", 1);

            RuleEngine<Ticket> engine = RuleEngine.<Ticket>builder()
                    .addRule(lowPriority)
                    .addRule(highPriority)
                    .strategy(ConflictResolutionStrategy.PRIORITY_BASED)
                    .build();

            EvaluationContext<Ticket> ctx = engine.evaluate(networkHighTicket);

            assertTrue(ctx.hasMatch());
            assertEquals("R2", ctx.winningResult().ruleId());
            assertEquals("sre-queue", ctx.winningResult().action());
            assertEquals(1, ctx.getConflictCount()); // 2 matches, 1 conflict
        }

        @Test
        @DisplayName("uses default action when no rules match")
        void defaultFallback() {
            Rule<Ticket> rule = buildExpressionRule("R1", "category == 'database'", "dba-queue", 1);

            RuleEngine<Ticket> engine = RuleEngine.<Ticket>builder()
                    .addRule(rule)
                    .defaultAction("general-queue")
                    .build();

            EvaluationContext<Ticket> ctx = engine.evaluate(networkHighTicket);

            assertTrue(ctx.hasMatch()); // default action counts as match
            assertEquals("DEFAULT", ctx.winningResult().ruleId());
            assertEquals("general-queue", ctx.winningResult().action());
        }

        @Test
        @DisplayName("dry-run flag propagates to context")
        void dryRunMode() {
            Rule<Ticket> rule = buildExpressionRule("R1", "category == 'network'", "netops", 1);

            RuleEngine<Ticket> engine = RuleEngine.<Ticket>builder()
                    .addRule(rule)
                    .build();

            EvaluationContext<Ticket> ctx = engine.evaluate(networkHighTicket, true);

            assertTrue(ctx.hasMatch());
            assertTrue(ctx.dryRun());
        }

        @Test
        @DisplayName("skips inactive rules")
        void skipsInactiveRules() {
            Rule<Ticket> active = buildExpressionRule("R1", "category == 'network'", "netops", 1);
            Rule<Ticket> inactive = new InactiveRule();

            RuleEngine<Ticket> engine = RuleEngine.<Ticket>builder()
                    .addRule(active)
                    .addRule(inactive)
                    .build();

            EvaluationContext<Ticket> ctx = engine.evaluate(networkHighTicket);
            assertEquals(1, ctx.allResults().size()); // only active rule evaluated
        }

        @Test
        @DisplayName("handles exception in rule evaluation gracefully")
        void handlesRuleException() {
            Rule<Ticket> badRule = new ExplodingRule();
            Rule<Ticket> goodRule = buildExpressionRule("R2", "category == 'network'", "netops", 1);

            RuleEngine<Ticket> engine = RuleEngine.<Ticket>builder()
                    .addRule(badRule)
                    .addRule(goodRule)
                    .build();

            // Should not throw — bad rule is caught and treated as no-match
            EvaluationContext<Ticket> ctx = engine.evaluate(networkHighTicket);
            assertTrue(ctx.hasMatch());
            assertEquals("R2", ctx.winningResult().ruleId());
        }
    }

    // ========== CONFLICT DETECTOR TESTS ==========

    @Nested
    @DisplayName("Conflict Detection")
    class ConflictDetectionTests {

        @Test
        @DisplayName("detects duplicate priorities")
        void detectsDuplicatePriority() {
            Rule<Ticket> r1 = buildExpressionRule("R1", "category == 'network'", "team-a", 1);
            Rule<Ticket> r2 = buildExpressionRule("R2", "source == 'monitoring'", "team-b", 1);

            ConflictDetector<Ticket> detector = new ConflictDetector<>();
            var conflicts = detector.detect(List.of(r1, r2));

            assertEquals(1, conflicts.size());
            assertEquals(ConflictDetector.ConflictType.DUPLICATE_PRIORITY, conflicts.getFirst().type());
        }

        @Test
        @DisplayName("detects duplicate IDs")
        void detectsDuplicateId() {
            Rule<Ticket> r1 = buildExpressionRule("R1", "category == 'network'", "team-a", 1);
            Rule<Ticket> r2 = buildExpressionRule("R1", "source == 'portal'", "team-b", 2);

            ConflictDetector<Ticket> detector = new ConflictDetector<>();
            var conflicts = detector.detect(List.of(r1, r2));

            assertTrue(conflicts.stream().anyMatch(c ->
                    c.type() == ConflictDetector.ConflictType.DUPLICATE_ID));
        }

        @Test
        @DisplayName("reports no conflicts for clean rule set")
        void noConflicts() {
            Rule<Ticket> r1 = buildExpressionRule("R1", "category == 'network'", "team-a", 1);
            Rule<Ticket> r2 = buildExpressionRule("R2", "category == 'hr'", "team-b", 2);

            ConflictDetector<Ticket> detector = new ConflictDetector<>();
            var conflicts = detector.detect(List.of(r1, r2));

            assertTrue(conflicts.isEmpty());
        }
    }

    // ========== TICKET IMMUTABILITY TESTS ==========

    @Nested
    @DisplayName("Ticket Immutability")
    class TicketImmutabilityTests {

        @Test
        @DisplayName("ticket fields are immutable after construction")
        void ticketIsImmutable() {
            Ticket ticket = Ticket.builder()
                    .id("T1")
                    .category("network")
                    .priority(Ticket.Priority.HIGH)
                    .build();

            assertEquals("network", ticket.getCategory());
            assertEquals(Ticket.Priority.HIGH, ticket.getPriority());
            // No setters available — immutability enforced at compile time
        }

        @Test
        @DisplayName("toBuilder creates independent copy")
        void toBuilderCreatesCopy() {
            Ticket original = Ticket.builder()
                    .id("T1").category("network").priority(Ticket.Priority.HIGH).build();

            Ticket modified = original.toBuilder()
                    .priority(Ticket.Priority.LOW).build();

            assertEquals(Ticket.Priority.HIGH, original.getPriority());
            assertEquals(Ticket.Priority.LOW, modified.getPriority());
        }

        @Test
        @DisplayName("getFieldValue supports dynamic field access")
        void dynamicFieldAccess() {
            assertEquals("network", networkHighTicket.getFieldValue("category"));
            assertEquals("HIGH", networkHighTicket.getFieldValue("priority"));
            assertNull(networkHighTicket.getFieldValue("nonexistent"));
        }
    }

    // ========== RULE RESULT IMMUTABILITY ==========

    @Nested
    @DisplayName("RuleResult Immutability")
    class RuleResultTests {

        @Test
        @DisplayName("metadata map is unmodifiable")
        void metadataIsUnmodifiable() {
            RuleResult<Ticket> result = RuleResult.match(
                    "R1", "test", networkHighTicket, "action", 1,
                    new java.util.HashMap<>() {{ put("key", "value"); }}, 5);

            assertThrows(UnsupportedOperationException.class,
                    () -> result.metadata().put("new", "value"));
        }
    }

    // ========== HELPERS ==========

    private ExpressionRule buildExpressionRule(String id, String expression,
                                                String action, int priority) {
        return ExpressionRule.builder()
                .id(id)
                .name("Test rule " + id)
                .expressionString(expression)
                .action(action)
                .priority(priority)
                .build();
    }

    /** Test helper: a rule that's always inactive */
    private static class InactiveRule implements Rule<Ticket> {
        @Override public String getId() { return "INACTIVE"; }
        @Override public String getName() { return "Inactive Rule"; }
        @Override public int getPriority() { return 1; }
        @Override public boolean isActive() { return false; }
        @Override public RuleResult<Ticket> evaluate(Ticket entity) {
            return RuleResult.match("INACTIVE", "Inactive", entity, "should-not-run", 1,
                    java.util.Map.of(), 0);
        }
    }

    /** Test helper: a rule that throws to test fault tolerance */
    private static class ExplodingRule implements Rule<Ticket> {
        @Override public String getId() { return "EXPLODING"; }
        @Override public String getName() { return "Exploding Rule"; }
        @Override public int getPriority() { return 1; }
        @Override public RuleResult<Ticket> evaluate(Ticket entity) {
            throw new RuntimeException("Boom! Rule evaluation failed");
        }
    }
}
